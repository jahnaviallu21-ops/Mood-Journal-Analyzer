# 🌿 Mood Journal Analyzer

> **Project #37: Mood Journal Analyzer**  
> **Domain:** Health & Wellbeing | Hackathon Mentor Guide  
> **Tech Stack:** Python 3.10+, Matplotlib, Tkinter, CSV, JSON, Unittest  

---

## 1. Project Overview & Problem Statement

### Problem Context
In academic and everyday environments, individuals frequently experience friction when attempting to track optional mood labels and understand long-term wellbeing patterns manually or with fragmented tools. Without an integrated, automated utility, records are susceptible to calculation errors, misplaced entries, and delayed status insights. Existing enterprise software solutions require steep learning curves, expensive licenses, or intrusive network setups unsuited for rapid, private, local workflows.

### Objective
**Mood Journal Analyzer** is a robust, beginner-friendly Python application engineered to enable users to record optional mood labels, validate entries in real time, persist data reliably across program restarts using local CSV and JSON storage, and generate clear executive summary reports and publication-quality visual trend charts.

---

## 2. Features & Requirements Mapping

### Core Features (Must-Have)
- [x] **Interactive Terminal Interface:** Menu-driven command prompt with ANSI color coding, branded header, and guided workflow steps.
- [x] **Defensive Input Validation:** Real-time sanitization, type-casting, and boundary checks for dates (`YYYY-MM-DD`), times (`HH:MM`), mood scores (1–10), energy levels (1–10), stress levels (1–10), and sleep hours (0.0–24.0).
- [x] **Core Business Logic Engine:** Computational algorithms programmed to track optional mood labels, calculate standard deviations (volatility index), rolling moving averages, day-of-week trends, streak lengths, and Pearson correlation coefficients (sleep vs. mood, stress vs. mood).
- [x] **Local Data Persistence:** Automated reading and writing to both JSON (`data/mood_journal.json`) and CSV (`data/mood_journal.csv`) ensuring data survives program restarts, with schema checks and corrupted file auto-recovery.
- [x] **Record Query & Search:** Keyword searching across reflection notes and tags, plus category-based filtering (mood label, score bounds, date ranges) presented in fixed-width paginated tables.
- [x] **Executive Summary Generation:** Comprehensive aggregation module computing totals, averages, status indicators (e.g. *Thriving*, *Balanced*, *Needs Attention*, *Critical Burnout Risk*), and key trajectory trends.
- [x] **Visual Data Plotting:** Matplotlib integration generating 4-panel executive dashboards, longitudinal trend lines, mood label distribution donut charts, and day-of-week bar charts, with an automated fallback to in-terminal ASCII trend graphs.

### Stretch Features (Good-to-Have)
- [x] **Multi-Format Summary Export:** Generates structured Markdown (`.md`), plain-text audit logs (`.txt`), standardized CSV reports (`.csv`), and machine-readable JSON summaries (`.json`) in the `exports/` directory.
- [x] **Threshold Warning Indicators:** Automated console flags highlighting overdue check-ins, acute mood drops ($\ge 4$ points), prolonged stress breaches ($\ge 8/10$ for $3+$ days), sleep deficit alerts ($<5$ hours), and critical burnout risks with actionable clinical recommendations.
- [x] **Interactive GUI Enhancement:** Modern, professional desktop GUI built with Python Tkinter and ttk, featuring a calming wellness color palette, KPI summary cards, embedded Matplotlib interactive charts, search/filter table, and one-click export buttons.
- [x] **Bulk Dataset Import:** Ingestion engine capable of reading external/legacy CSV files with flexible column alias resolution, schema validation, and detailed row-by-row error logs.

---

## 3. Project Directory Structure

```
mood_journal_analyzer/
│
├── data/
│   ├── mood_journal.json           # Active primary JSON persistent store
│   ├── mood_journal.csv            # Synchronized active CSV persistent store
│   ├── sample_data.json            # Curated seed dataset (38 realistic entries)
│   ├── sample_data.csv             # Curated seed dataset in CSV format
│   ├── legacy_import_sample.csv    # Legacy dataset with valid & intentional invalid rows
│   ├── audit.log                   # Persistent operational audit log
│   └── seed_generator.py           # Dataset generation utility
│
├── exports/                        # Generated charts and exported reports
│   ├── mood_report_dashboard.png   # 4-panel high-res Matplotlib dashboard
│   ├── mood_report_trend.png       # Longitudinal mood & stress trend chart
│   ├── mood_report_distribution.png# Mood label frequency chart
│   ├── mood_report_sleep_vs_mood.png # Sleep correlation scatter plot
│   ├── mood_report_day_of_week.png # Day of week average mood bar chart
│   └── mood_report_*.md / .csv / .txt / .json
│
├── src/
│   ├── __init__.py                 # Package initialization
│   ├── models.py                   # Dataclasses: MoodEntry, FilterCriteria, AggregateSummary, WarningAlert
│   ├── validator.py                # Defensive sanitization, regex checks, and boundary validation
│   ├── storage.py                  # Fault-tolerant dual persistence (JSON/CSV) with auto-recovery
│   ├── analytics.py                # Statistical aggregations, moving averages, trends, and correlations
│   ├── warnings.py                 # Anomaly detection & threshold warning indicators
│   ├── importer.py                 # Bulk CSV dataset ingestion engine with row error logs
│   ├── exporters.py                # Multi-format report exporter (Markdown, CSV, TXT, JSON)
│   ├── plotter.py                  # Matplotlib chart generator with ASCII terminal fallback
│   ├── cli.py                      # Interactive menu-driven terminal interface with pagination
│   └── gui.py                      # Modern, attractive Tkinter GUI dashboard
│
├── tests/
│   ├── __init__.py
│   ├── test_models_and_validation.py # Unit tests for models & defensive validation
│   ├── test_storage.py             # Unit tests for persistence, atomic saves, & recovery
│   ├── test_analytics_and_warnings.py # Unit tests for calculations, trends, & alerts
│   ├── test_importer_and_exporters.py # Unit tests for bulk import & report exports
│   ├── test_end_to_end.py          # Complete simulated user journey & persistence test
│   └── run_tests.py                # Standalone test runner script
│
├── main.py                         # Application CLI/GUI entry point
├── requirements.txt                # Dependencies specification (matplotlib)
└── README.md                       # Comprehensive documentation
```

---

## 4. Design & Color Palette

The interface adheres to an intentional, calming health & wellbeing theme designed for clarity, high contrast, and reduced visual strain:

| Element | Hex Code | Purpose / Semantic Meaning |
| :--- | :---: | :--- |
| **Primary Navy / Indigo** | `#1D4ED8` / `#2B4C7E` | Main branding, navigation headers, primary accents |
| **Calm Teal** | `#0D9488` | Secondary action buttons, data export controls |
| **Emerald Green** | `#10B981` | Positive indicators, high mood ($\ge 7$), thriving wellness |
| **Warm Amber** | `#F59E0B` | Warnings, moderate stress, informational notices |
| **Coral Red** | `#EF4444` | High stress, critical burnout risk, acute drops |
| **Card White** | `#FFFFFF` | Structured content cards, clean data tables |
| **Background Slate** | `#F1F5F9` | Soft, low-contrast background for eye comfort |

---

## 5. Installation & Setup

### Prerequisites
- Python 3.10 or higher.
- `pip` (Python package manager).

### Step-by-Step Installation

1. **Extract or Clone the Project:**
   ```bash
   cd mood_journal_analyzer
   ```

2. **(Optional) Create and Activate a Virtual Environment:**
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate

   # macOS / Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

---

## 6. How to Run the Application

The application provides multiple execution modes tailored for terminal power users, desktop GUI workflows, and automated reporting:

### Option A: Interactive Terminal Interface (Default)
Launch the interactive menu-driven console with ANSI styling:
```bash
python main.py
```
*Or explicitly:*
```bash
python main.py --cli
```

### Option B: Modern Graphical User Interface (Tkinter GUI)
Launch the modern desktop application:
```bash
python main.py --gui
```
*(You can also launch the GUI directly from Option 9 in the terminal menu!)*

### Option C: Instant Summary Flag
Generate the executive wellbeing summary in terminal and exit:
```bash
python main.py --summary
```

### Option D: Anomaly & Warning Inspection Flag
Run the threshold warning indicators and display active alerts:
```bash
python main.py --check-warnings
```

### Option E: Multi-Format Report Export Flag
Generate all Markdown, CSV, plain-text audit, and JSON reports in `exports/`:
```bash
python main.py --export
```

---

## 7. Running the Automated Test Suite

A comprehensive test suite of 20 unit, integration, and end-to-end tests is included.

To run all tests:
```bash
python tests/run_tests.py
```
*Or using Python's standard test runner:*
```bash
python -m unittest discover -s tests -p "test_*.py" -v
```

All 20 tests verify:
1. Defensive validation rules against non-numeric, blank, out-of-bounds, and malformed inputs.
2. Dual persistence to JSON and CSV with corrupted file auto-recovery.
3. Accurate statistical aggregations, streaks, moving averages, and Pearson correlation.
4. Threshold warning flags for burnout risk, sleep deficit, and acute drops.
5. Flexible bulk CSV column mapping and row error logging.
6. End-to-end workflow and persistence across application restarts.

---

## 8. Hackathon Demonstration Walkthrough

Follow this 5-minute evaluation script to demonstrate every requirement:

1. **Launch the Application:** Run `python main.py`. Point out the branded welcome banner and the 38 pre-seeded realistic entries across multiple weeks.
2. **Demonstrate Defensive Validation:**
   - Select Option `1` (Record New Entry).
   - Intentionally type invalid values: enter an invalid date like `2026-13-40`, an invalid mood score like `15`, or negative sleep like `-3`.
   - Observe how the centralized validator traps each invalid input with a friendly message and loops safely without crashing.
   - Enter valid details (e.g., Date: `2026-11-21`, Mood: `9`, Label: `Joyful`, Energy: `8`, Stress: `2`, Sleep: `8.0`).
3. **Execute Analytics & Executive Summary:**
   - Select Option `3`.
   - Review the computed metrics: Average Mood, Volatility Index ($\sigma$), Current & Longest Streaks, Best Day of Week, and the Wellness Status Badge.
4. **Inspect Threshold Warnings:**
   - Select Option `4`.
   - Review automated clinical warning flags detecting historical high stress periods and mood drops with actionable recovery recommendations.
5. **Demonstrate Visual Plotting:**
   - Select Option `5`.
   - Observe the in-terminal Unicode ASCII chart and the exported Matplotlib publication-grade PNG charts in `exports/`.
6. **Demonstrate Bulk Import & Error Logging:**
   - Select Option `7`.
   - Hit Enter to ingest `data/legacy_import_sample.csv`.
   - Note how valid rows are mapped and accepted, while the 4 intentional corrupt rows are logged in a row-by-row audit report with reasons.
7. **Launch the Graphical Interface:**
   - Select Option `9` or run `python main.py --gui`.
   - Show the interactive KPI cards, embedded visual chart, search/filter table, and one-click export buttons.
8. **Verify Persistence Across Restarts:**
   - Exit the application (Option `0`).
   - Relaunch `python main.py --summary`. Notice that all recorded and imported entries were permanently preserved!

---

## 9. Future Scope & Roadmap
- Integration with wearable API webhooks (e.g. Fitbit, Apple Health, Oura) for automatic sleep and heart rate data synchronization.
- Natural Language Processing (NLP) sentiment scoring on journal reflection notes.
- Secure optional multi-user profiles with encrypted local vaults.
- Mobile companion application via Flutter or React Native.

---

## 10. License
This project is developed for educational and hackathon submission purposes under the MIT License.
