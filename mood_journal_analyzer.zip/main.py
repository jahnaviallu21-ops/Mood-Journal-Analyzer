"""
Mood Journal Analyzer - Main Entry Point
========================================
Project #37: Mood Journal Analyzer | Domain: Health & Wellbeing
A robust, beginner-friendly Python application engineered to record optional mood labels,
validate entries defensively, persist data to CSV/JSON, track trends, and present actionable summaries.
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.storage import StorageManager
from src.cli import CLIApp
from src.analytics import generate_executive_summary
from src.warnings import WarningEngine
from src.exporters import ReportExporter


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mood Journal Analyzer: Health & Wellbeing Tracking and Analytics Engine."
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch the modern Graphical User Interface (Tkinter)."
    )
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Launch the Interactive Terminal Interface (Default)."
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Display Executive Wellbeing Summary in terminal and exit."
    )
    parser.add_argument(
        "--export",
        action="store_true",
        help="Export multi-format reports (Markdown, CSV, TXT, JSON) and exit."
    )
    parser.add_argument(
        "--check-warnings",
        action="store_true",
        help="Run threshold warning indicators and anomaly checks and exit."
    )

    args = parser.parse_args()
    storage = StorageManager()

    if args.gui:
        try:
            from src.gui import launch_gui
            launch_gui()
        except Exception as e:
            print(f"[Error] Failed to start GUI: {e}")
            print("Falling back to interactive terminal interface...")
            app = CLIApp(storage)
            app.run()

    elif args.summary:
        entries, _ = storage.load_entries()
        summary = generate_executive_summary(entries)
        print("\n" + "=" * 60)
        print("MOOD JOURNAL ANALYZER - EXECUTIVE SUMMARY")
        print("=" * 60)
        print(f"Total Entries  : {summary.total_entries}")
        print(f"Period         : {summary.date_range_str}")
        print(f"Wellness Status: {summary.wellness_status}")
        print(f"Mood Trajectory: {summary.mood_trend}")
        print(f"Average Mood   : {summary.avg_mood:.2f} / 10 (Min: {summary.min_mood}, Max: {summary.max_mood})")
        print(f"Volatility (σ) : {summary.mood_volatility:.2f}")
        print(f"Average Energy : {summary.avg_energy:.2f} / 10")
        print(f"Average Stress : {summary.avg_stress:.2f} / 10")
        print(f"Average Sleep  : {summary.avg_sleep:.1f} hrs")
        print(f"Current Streak : {summary.current_streak_days} days (Longest: {summary.longest_streak_days} days)")
        print(f"Best Day       : {summary.best_day_of_week}")
        print(f"Challenging Day: {summary.worst_day_of_week}")
        print("=" * 60 + "\n")

    elif args.check_warnings:
        entries, _ = storage.load_entries()
        alerts = WarningEngine.evaluate_all(entries)
        print("\n" + "=" * 60)
        print("THRESHOLD WARNINGS & ANOMALY CHECKS")
        print("=" * 60)
        if not alerts:
            print("All metrics within healthy parameters. No warnings active.")
        else:
            for a in alerts:
                print(f"[{a.severity}] {a.category} ({a.date or 'N/A'}): {a.message}")
                print(f"  Action: {a.recommendation}\n")
        print("=" * 60 + "\n")

    elif args.export:
        entries, _ = storage.load_entries()
        exporter = ReportExporter()
        results = exporter.export_all(entries)
        print("\n" + "=" * 60)
        print("EXPORT MULTI-FORMAT WELLNESS REPORTS")
        print("=" * 60)
        for fmt, p in results.items():
            print(f"{fmt.upper():<10}: {p}")
        print("=" * 60 + "\n")

    else:
        # Default interactive menu
        app = CLIApp(storage)
        app.run()


if __name__ == "__main__":
    main()
