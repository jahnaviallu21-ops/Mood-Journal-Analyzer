"""
Unit tests for domain models, dataclasses, and defensive input validation.
"""

import unittest
from datetime import date, timedelta

from src.models import MoodEntry, FilterCriteria, AggregateSummary, WarningAlert
from src.validator import (
    validate_date,
    validate_time,
    validate_int_range,
    validate_sleep_hours,
    validate_mood_label,
    validate_tags,
    sanitize_text,
    validate_entry_dict,
)


class TestModelsAndValidation(unittest.TestCase):
    def test_mood_entry_serialization(self):
        """Test round-trip serialization to/from dict and CSV."""
        entry = MoodEntry(
            id="MJ-TEST-001",
            date="2026-11-20",
            time="14:30",
            mood_score=8,
            mood_label="Joyful",
            energy_level=7,
            stress_level=3,
            sleep_hours=7.5,
            tags=["exercise", "work"],
            notes="Productive day.",
        )

        d = entry.to_dict()
        self.assertEqual(d["id"], "MJ-TEST-001")
        self.assertEqual(d["mood_score"], 8)
        self.assertEqual(d["mood_label"], "Joyful")

        reconstructed = MoodEntry.from_dict(d)
        self.assertEqual(reconstructed.id, entry.id)
        self.assertEqual(reconstructed.tags, ["exercise", "work"])

        csv_row = entry.to_csv_row()
        self.assertEqual(csv_row["mood_score"], "8")
        from_csv = MoodEntry.from_csv_row(csv_row)
        self.assertEqual(from_csv.mood_score, 8)
        self.assertEqual(from_csv.tags, ["exercise", "work"])

    def test_validate_date(self):
        """Test defensive date parsing and boundary validation."""
        valid, err, val = validate_date("2026-10-15")
        self.assertTrue(valid)
        self.assertEqual(val, "2026-10-15")

        # Invalid formats
        self.assertFalse(validate_date("15-10-2026")[0])
        self.assertFalse(validate_date("invalid-date")[0])
        self.assertFalse(validate_date("")[0])
        self.assertFalse(validate_date(None)[0])

        # Impossible calendar day
        self.assertFalse(validate_date("2026-02-31")[0])
        self.assertFalse(validate_date("2026-13-10")[0])

        # Future date without allowance
        future = (date.today() + timedelta(days=5)).strftime("%Y-%m-%d")
        self.assertFalse(validate_date(future, allow_future=False)[0])
        self.assertTrue(validate_date(future, allow_future=True)[0])

    def test_validate_time(self):
        """Test 24-hour time string checks."""
        self.assertTrue(validate_time("14:30")[0])
        self.assertTrue(validate_time("00:00")[0])
        self.assertTrue(validate_time("23:59")[0])

        self.assertFalse(validate_time("24:00")[0])
        self.assertFalse(validate_time("12:65")[0])
        self.assertFalse(validate_time("9:30pm")[0])
        self.assertFalse(validate_time("")[0])

    def test_validate_int_range(self):
        """Test defensive integer boundary validation."""
        valid, _, val = validate_int_range("7", 1, 10)
        self.assertTrue(valid)
        self.assertEqual(val, 7)

        # Boundary extremes
        self.assertTrue(validate_int_range(1, 1, 10)[0])
        self.assertTrue(validate_int_range(10, 1, 10)[0])

        # Out of bounds
        self.assertFalse(validate_int_range(0, 1, 10)[0])
        self.assertFalse(validate_int_range(11, 1, 10)[0])
        self.assertFalse(validate_int_range("abc", 1, 10)[0])
        self.assertFalse(validate_int_range(7.5, 1, 10)[0])
        self.assertFalse(validate_int_range("", 1, 10)[0])
        self.assertFalse(validate_int_range(None, 1, 10)[0])

    def test_validate_sleep_hours(self):
        """Test sleep duration decimal bounds."""
        self.assertTrue(validate_sleep_hours("7.5")[0])
        self.assertTrue(validate_sleep_hours(0.0)[0])
        self.assertTrue(validate_sleep_hours(24.0)[0])

        self.assertFalse(validate_sleep_hours(-1.0)[0])
        self.assertFalse(validate_sleep_hours(25.0)[0])
        self.assertFalse(validate_sleep_hours("many hours")[0])

    def test_validate_mood_label(self):
        """Test optional mood label validation."""
        # Optional - None or blank is completely valid
        self.assertTrue(validate_mood_label(None)[0])
        self.assertTrue(validate_mood_label("")[0])
        self.assertTrue(validate_mood_label("   ")[0])

        # Valid text
        v, _, clean = validate_mood_label("joyful")
        self.assertTrue(v)
        self.assertEqual(clean, "Joyful")

        # Invalid characters or excessively long
        self.assertFalse(validate_mood_label("<script>alert(1)</script>")[0])
        self.assertFalse(validate_mood_label("a" * 50)[0])

    def test_validate_tags(self):
        """Test tag list parsing and cleaning."""
        v, _, tags = validate_tags("work, Exercise; Outdoor, WORK")
        self.assertTrue(v)
        self.assertEqual(tags, ["work", "exercise", "outdoor"])

        v2, _, tags2 = validate_tags(["Study", "Exam", "study"])
        self.assertTrue(v2)
        self.assertEqual(tags2, ["study", "exam"])

    def test_validate_entry_dict(self):
        """Test comprehensive dictionary validation."""
        payload = {
            "date": "2026-11-15",
            "time": "10:00",
            "mood_score": "8",
            "mood_label": "Grateful",
            "energy_level": "7",
            "stress_level": "3",
            "sleep_hours": "8.0",
            "tags": "family, morning",
            "notes": "Wonderful Sunday breakfast.",
        }
        is_valid, errors, cleaned = validate_entry_dict(payload)
        self.assertTrue(is_valid)
        self.assertEqual(errors, {})
        self.assertEqual(cleaned["mood_score"], 8)
        self.assertEqual(cleaned["mood_label"], "Grateful")

        # Invalid payload
        bad_payload = {
            "date": "invalid",
            "mood_score": "99",
            "sleep_hours": "-5",
        }
        is_valid2, errors2, _ = validate_entry_dict(bad_payload)
        self.assertFalse(is_valid2)
        self.assertIn("date", errors2)
        self.assertIn("mood_score", errors2)
        self.assertIn("sleep_hours", errors2)


if __name__ == "__main__":
    unittest.main()
