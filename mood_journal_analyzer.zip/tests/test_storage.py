"""
Unit tests for local file storage, schema integrity, and corrupt file recovery.
"""

import unittest
import tempfile
import shutil
import json
from pathlib import Path

from src.models import MoodEntry
from src.storage import StorageManager


class TestStorageManager(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.storage = StorageManager(data_dir=self.test_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_initial_templates_created(self):
        """Ensure clean initial JSON and CSV files exist upon startup."""
        json_file = Path(self.test_dir) / "mood_journal.json"
        csv_file = Path(self.test_dir) / "mood_journal.csv"

        self.assertTrue(json_file.exists())
        self.assertTrue(csv_file.exists())

        entries, warnings = self.storage.load_entries()
        self.assertEqual(entries, [])
        self.assertEqual(warnings, [])

    def test_add_and_retrieve_entry(self):
        """Test adding a record and reading it back."""
        entry = MoodEntry(
            id="MJ-UNIT-1",
            date="2026-11-10",
            time="10:00",
            mood_score=8,
            mood_label="Motivated",
            energy_level=7,
            stress_level=3,
            sleep_hours=7.5,
            tags=["focus"],
            notes="Starting new project.",
        )

        success, _ = self.storage.add_entry(entry)
        self.assertTrue(success)

        retrieved = self.storage.get_entry_by_id("MJ-UNIT-1")
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.mood_score, 8)
        self.assertEqual(retrieved.mood_label, "Motivated")

        # Verify dual persistence - CSV also updated
        loaded_entries, _ = self.storage.load_entries()
        self.assertEqual(len(loaded_entries), 1)

    def test_update_and_delete_entry(self):
        """Test updating and deleting existing records."""
        entry = MoodEntry(
            id="MJ-UNIT-2",
            date="2026-11-11",
            time="11:00",
            mood_score=6,
            mood_label="Neutral",
        )
        self.storage.add_entry(entry)

        # Update
        entry.mood_score = 9
        entry.mood_label = "Joyful"
        success_up, _ = self.storage.update_entry(entry)
        self.assertTrue(success_up)

        updated = self.storage.get_entry_by_id("MJ-UNIT-2")
        self.assertEqual(updated.mood_score, 9)
        self.assertEqual(updated.mood_label, "Joyful")

        # Delete
        success_del, _ = self.storage.delete_entry("MJ-UNIT-2")
        self.assertTrue(success_del)
        self.assertIsNone(self.storage.get_entry_by_id("MJ-UNIT-2"))

    def test_corrupt_json_recovery(self):
        """Test automatic recovery from corrupted JSON via CSV fallback."""
        entry = MoodEntry(
            id="MJ-UNIT-RECOVER",
            date="2026-11-12",
            time="12:00",
            mood_score=7,
            mood_label="Calm",
        )
        self.storage.add_entry(entry)

        # Intentionally corrupt the JSON file
        json_file = Path(self.test_dir) / "mood_journal.json"
        with open(json_file, "w", encoding="utf-8") as f:
            f.write("<<< INVALID BROKEN CORRUPTED JSON >>>")

        # Load should recover from CSV and warn
        recovered_entries, warnings = self.storage.load_entries()
        self.assertEqual(len(recovered_entries), 1)
        self.assertEqual(recovered_entries[0].id, "MJ-UNIT-RECOVER")
        self.assertTrue(any("Corrupted JSON" in w for w in warnings))


if __name__ == "__main__":
    unittest.main()
