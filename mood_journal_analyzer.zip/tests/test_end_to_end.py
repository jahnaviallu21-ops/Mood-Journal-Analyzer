"""
End-to-End User Journey and Persistence Integration Test.
Simulates a complete hackathon user journey:
1. Initialize storage and verify template generation.
2. Record entries (testing defensive boundary validation).
3. Query and filter stored records.
4. Compute executive analytics and threshold warnings.
5. Generate Matplotlib visual plots and multi-format exports.
6. Ingest legacy CSV dataset with error logs.
7. Restart application to verify state persistence across restarts.
"""

import unittest
import tempfile
import shutil
from pathlib import Path

from src.models import MoodEntry, FilterCriteria
from src.validator import validate_entry_dict
from src.storage import StorageManager
from src.analytics import generate_executive_summary, filter_entries
from src.warnings import WarningEngine
from src.plotter import MoodPlotter
from src.exporters import ReportExporter
from src.importer import BulkImporter


class TestEndToEndWorkflow(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.data_dir = Path(self.test_dir) / "data"
        self.exports_dir = Path(self.test_dir) / "exports"
        self.storage = StorageManager(data_dir=str(self.data_dir))
        self.plotter = MoodPlotter(exports_dir=self.exports_dir)
        self.exporter = ReportExporter(exports_dir=self.exports_dir)
        self.importer = BulkImporter(exports_dir=self.exports_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_complete_hackathon_demo_flow(self):
        """Simulate end-to-end journey as outlined in PDF Section 9."""
        # Step 1: Initial state is clean
        entries, warnings = self.storage.load_entries()
        self.assertEqual(len(entries), 0)

        # Step 2: Attempting invalid entry is rejected defensively
        bad_entry_payload = {
            "date": "2026-99-99", # Invalid date
            "mood_score": 15,     # > 10
            "sleep_hours": -2.0,  # Negative
        }
        valid, errs, _ = validate_entry_dict(bad_entry_payload)
        self.assertFalse(valid)
        self.assertIn("date", errs)
        self.assertIn("mood_score", errs)
        self.assertIn("sleep_hours", errs)

        # Step 3: Add valid entries
        entry1 = MoodEntry(
            id="MJ-DEMO-01",
            date="2026-11-18",
            time="08:30",
            mood_score=8,
            mood_label="Joyful",
            energy_level=8,
            stress_level=2,
            sleep_hours=8.0,
            tags=["demo", "hackathon"],
            notes="Ready for presentation.",
        )
        entry2 = MoodEntry(
            id="MJ-DEMO-02",
            date="2026-11-19",
            time="19:00",
            mood_score=7,
            mood_label="Calm",
            energy_level=7,
            stress_level=3,
            sleep_hours=7.5,
            tags=["demo"],
            notes="Steady progress.",
        )
        entry3 = MoodEntry(
            id="MJ-DEMO-03",
            date="2026-11-20",
            time="21:30",
            mood_score=9,
            mood_label="Grateful",
            energy_level=9,
            stress_level=2,
            sleep_hours=8.5,
            tags=["milestone"],
            notes="Submission ready!",
        )

        self.storage.add_entry(entry1)
        self.storage.add_entry(entry2)
        self.storage.add_entry(entry3)

        # Step 4: Query records
        filtered = filter_entries(self.storage.load_entries()[0], FilterCriteria(keyword="hackathon"))
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].id, "MJ-DEMO-01")

        # Step 5: Compute Executive Summary
        current_entries, _ = self.storage.load_entries()
        summary = generate_executive_summary(current_entries)
        self.assertEqual(summary.total_entries, 3)
        self.assertEqual(summary.min_mood, 7)
        self.assertEqual(summary.max_mood, 9)
        self.assertAlmostEqual(summary.avg_mood, 8.0, places=1)
        self.assertEqual(summary.wellness_status, "Thriving (Optimal Wellbeing)")

        # Step 6: Warning Indicators
        alerts = WarningEngine.evaluate_all(current_entries)
        # All entries are healthy, so no critical warnings
        criticals = [a for a in alerts if a.severity == "CRITICAL"]
        self.assertEqual(len(criticals), 0)

        # Step 7: Export Multi-Format Reports
        export_paths = self.exporter.export_all(current_entries, base_name="demo_run")
        for fmt, path in export_paths.items():
            self.assertTrue(Path(path).exists())

        # Step 8: Visual Plotting
        if self.plotter.is_available:
            plot_paths = self.plotter.generate_all_plots(current_entries, base_name="demo_plots")
            self.assertIn("dashboard", plot_paths)
            self.assertTrue(Path(plot_paths["dashboard"]).exists())

        # Step 9: Bulk Import Legacy CSV with Errors
        legacy_csv = Path(self.test_dir) / "legacy_test.csv"
        with open(legacy_csv, "w", encoding="utf-8") as f:
            f.write("Entry Date,Time,Mood Rating,Feeling,Energy Score,Tension,Hours Slept,Tags,Reflection\n")
            f.write("2026-11-21,12:00,8,Calm,7,3,7.5,legacy,Legacy row 1\n")
            f.write("2026-99-99,12:00,8,BadDate,7,3,7.5,legacy,Invalid date row\n")

        import_summary = self.importer.import_csv_file(str(legacy_csv))
        self.assertEqual(import_summary.accepted_count, 1)
        self.assertEqual(import_summary.rejected_count, 1)

        # Merge valid row
        current_entries.extend(import_summary.imported_entries)
        self.storage.save_entries(current_entries)

        # Step 10: Close & Relaunch Simulation (State Persistence across program restart)
        restarted_storage = StorageManager(data_dir=str(self.data_dir))
        persisted_entries, _ = restarted_storage.load_entries()

        # Should have 3 original entries + 1 imported valid entry = 4 entries
        self.assertEqual(len(persisted_entries), 4)
        ids = [e.id for e in persisted_entries]
        self.assertIn("MJ-DEMO-01", ids)
        self.assertIn("MJ-DEMO-02", ids)
        self.assertIn("MJ-DEMO-03", ids)


if __name__ == "__main__":
    unittest.main()
