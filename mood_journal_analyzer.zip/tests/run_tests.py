"""
Test Runner Script for Mood Journal Analyzer.
Executes all unit and integration test suites.
"""

import sys
import unittest
from pathlib import Path

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


def run_all_tests():
    print("=" * 70)
    print("MOOD JOURNAL ANALYZER - TEST SUITE EXECUTION")
    print("=" * 70)

    loader = unittest.TestLoader()
    suite = loader.discover(
        start_dir=str(PROJECT_ROOT / "tests"),
        pattern="test_*.py",
        top_level_dir=str(PROJECT_ROOT),
    )

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("=" * 70)
    if result.wasSuccessful():
        print(f"✅ ALL {result.testsRun} TESTS PASSED SUCCESSFULLY!")
        return 0
    else:
        print(f"❌ {len(result.failures)} failures and {len(result.errors)} errors encountered.")
        return 1


if __name__ == "__main__":
    sys.exit(run_all_tests())
