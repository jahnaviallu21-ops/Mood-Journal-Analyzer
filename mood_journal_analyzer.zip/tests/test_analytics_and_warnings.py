"""
Unit tests for analytics calculations, trends, filters, correlations, and warnings.
"""

import unittest
from datetime import date

from src.models import MoodEntry, FilterCriteria
from src.analytics import (
    filter_entries,
    calculate_standard_deviation,
    calculate_pearson_correlation,
    determine_mood_trend,
    calculate_streaks,
    calculate_day_of_week_analysis,
    calculate_moving_averages,
    generate_executive_summary,
)
from src.warnings import WarningEngine


class TestAnalyticsAndWarnings(unittest.TestCase):
    def setUp(self):
        self.sample_entries = [
            MoodEntry(id="E1", date="2026-11-01", time="09:00", mood_score=5, mood_label="Neutral", energy_level=5, stress_level=4, sleep_hours=6.5, tags=["work"], notes="Okay day."),
            MoodEntry(id="E2", date="2026-11-02", time="09:00", mood_score=6, mood_label="Calm", energy_level=6, stress_level=3, sleep_hours=7.0, tags=["walk"], notes="Peaceful walk."),
            MoodEntry(id="E3", date="2026-11-03", time="09:00", mood_score=8, mood_label="Motivated", energy_level=8, stress_level=3, sleep_hours=8.0, tags=["work", "coding"], notes="Great progress."),
            MoodEntry(id="E4", date="2026-11-04", time="09:00", mood_score=9, mood_label="Joyful", energy_level=9, stress_level=2, sleep_hours=8.5, tags=["celebration"], notes="Milestone reached!"),
        ]

    def test_filter_entries(self):
        """Test multi-criteria filtering."""
        # Keyword filter in notes
        crit_kw = FilterCriteria(keyword="milestone")
        res_kw = filter_entries(self.sample_entries, crit_kw)
        self.assertEqual(len(res_kw), 1)
        self.assertEqual(res_kw[0].id, "E4")

        # Mood label filter
        crit_lbl = FilterCriteria(mood_label="Calm")
        res_lbl = filter_entries(self.sample_entries, crit_lbl)
        self.assertEqual(len(res_lbl), 1)
        self.assertEqual(res_lbl[0].mood_score, 6)

        # Min score filter
        crit_min = FilterCriteria(min_mood_score=8)
        res_min = filter_entries(self.sample_entries, crit_min)
        self.assertEqual(len(res_min), 2)

        # Date range filter
        crit_date = FilterCriteria(start_date="2026-11-02", end_date="2026-11-03")
        res_date = filter_entries(self.sample_entries, crit_date)
        self.assertEqual(len(res_date), 2)

    def test_math_and_stats(self):
        """Test standard deviation, moving averages, and Pearson correlation."""
        vals = [5.0, 6.0, 8.0, 9.0]
        std = calculate_standard_deviation(vals)
        self.assertGreater(std, 1.0)

        # Positive correlation between sleep and mood in this dataset
        sleeps = [e.sleep_hours for e in self.sample_entries]
        moods = [float(e.mood_score) for e in self.sample_entries]
        r = calculate_pearson_correlation(sleeps, moods)
        self.assertGreater(r, 0.90)  # Strong positive correlation

        # Trend should be improving
        trend = determine_mood_trend(self.sample_entries)
        self.assertIn("Improving", trend)

    def test_executive_summary_generation(self):
        """Test executive summary metrics computation."""
        summary = generate_executive_summary(self.sample_entries)
        self.assertEqual(summary.total_entries, 4)
        self.assertEqual(summary.min_mood, 5)
        self.assertEqual(summary.max_mood, 9)
        self.assertAlmostEqual(summary.avg_mood, 7.0, places=1)
        self.assertAlmostEqual(summary.avg_sleep, 7.5, places=1)
        self.assertEqual(summary.current_streak_days, 0)  # Entries in the past relative to today

    def test_warning_engine_triggers(self):
        """Test threshold warning indicators."""
        bad_entries = [
            MoodEntry(id="B1", date="2026-11-10", time="08:00", mood_score=9, mood_label="Joyful", stress_level=2, sleep_hours=8.0),
            MoodEntry(id="B2", date="2026-11-11", time="08:00", mood_score=4, mood_label="Stressed", stress_level=8, sleep_hours=4.0), # Drop of 5
            MoodEntry(id="B3", date="2026-11-12", time="08:00", mood_score=3, mood_label="Overwhelmed", stress_level=9, sleep_hours=3.5), # Stress 9, Burnout
            MoodEntry(id="B4", date="2026-11-13", time="08:00", mood_score=2, mood_label="Exhausted", stress_level=9, sleep_hours=4.0), # 3rd stress >= 8
        ]

        alerts = WarningEngine.evaluate_all(bad_entries, reference_date=date(2026, 11, 14))

        categories = [a.category for a in alerts]
        self.assertIn("MOOD_DROP", categories)
        self.assertIn("PROLONGED_STRESS", categories)
        self.assertIn("BURNOUT_RISK", categories)
        self.assertIn("SLEEP_DEFICIT", categories)

        # Check severity sorting: CRITICAL comes first
        self.assertEqual(alerts[0].severity, "CRITICAL")


if __name__ == "__main__":
    unittest.main()
