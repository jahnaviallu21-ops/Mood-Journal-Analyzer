"""
Unit tests for bulk CSV importer (with row error logs) and report exporters.
"""

import unittest
import tempfile
import shutil
from pathlib import Path

from src.models import MoodEntry
from src.importer import BulkImporter, normalize_headers
from src.exporters import ReportExporter


class TestImporterAndExporters(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.exports_dir = Path(self.test_dir) / "exports"
        self.importer = BulkImporter(exports_dir=self.exports_dir)
        self.exporter = ReportExporter(exports_dir=self.exports_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_normalize_headers(self):
        """Test flexible legacy header aliasing."""
        raw = ["Entry_Date", "Mood_Rating", "Feeling", "Hours_Slept", "Tension", "Reflection"]
        mapping = normalize_headers(raw)

        self.assertIn("date", mapping)
        self.assertIn("mood_score", mapping)
        self.assertIn("mood_label", mapping)
        self.assertIn("sleep_hours", mapping)
        self.assertIn("stress_level", mapping)
        self.assertIn("notes", mapping)

    def test_bulk_importer_with_errors(self):
        """Test row-by-row validation with accepted and rejected rows."""
        csv_path = Path(self.test_dir) / "test_legacy.csv"
        content = (
            "Entry Date,Time,Mood Rating,Feeling,Energy Score,Tension,Hours Slept,Tags,Reflection\n"
            "2026-11-01,09:00,8,Calm,7,3,7.5,work,Valid Row 1\n"
            "2026-13-99,09:00,8,BadDate,7,3,7.5,work,Invalid date row\n"
            "2026-11-02,09:00,25,BadScore,7,3,7.5,work,Invalid score 25\n"
            "2026-11-03,09:00,7,Content,6,4,8.0,home,Valid Row 2\n"
        )
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write(content)

        summary = self.importer.import_csv_file(str(csv_path))

        self.assertEqual(summary.total_rows, 4)
        self.assertEqual(summary.accepted_count, 2)
        self.assertEqual(summary.rejected_count, 2)
        self.assertTrue(Path(summary.log_file_path).exists())

        # Verify audit log details
        with open(summary.log_file_path, "r", encoding="utf-8") as f:
            log_text = f.read()
            self.assertIn("Row 002 | [ACCEPTED]", log_text)
            self.assertIn("Row 003 | [REJECTED]", log_text)
            self.assertIn("Row 004 | [REJECTED]", log_text)
            self.assertIn("Row 005 | [ACCEPTED]", log_text)

    def test_report_exporters(self):
        """Test generating Markdown, CSV, plain-text audit, and JSON reports."""
        entries = [
            MoodEntry(id="E1", date="2026-11-01", time="08:00", mood_score=7, mood_label="Calm", energy_level=6, stress_level=3, sleep_hours=7.5),
            MoodEntry(id="E2", date="2026-11-02", time="08:00", mood_score=8, mood_label="Joyful", energy_level=8, stress_level=2, sleep_hours=8.0),
        ]

        results = self.exporter.export_all(entries, base_name="test_report")

        for fmt in ["markdown", "csv", "text", "json"]:
            self.assertIn(fmt, results)
            file_path = Path(results[fmt])
            self.assertTrue(file_path.exists())
            self.assertGreater(file_path.stat().st_size, 50)


if __name__ == "__main__":
    unittest.main()
