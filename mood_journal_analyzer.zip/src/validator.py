"""
Defensive input validation and sanitization routines for Mood Journal Analyzer.
Ensures zero crashes from invalid, blank, non-numeric, or malicious inputs.
"""

import re
from datetime import datetime, date
from typing import Tuple, Optional, List, Dict, Any

STANDARD_MOOD_LABELS = [
    "Joyful",
    "Calm",
    "Content",
    "Motivated",
    "Grateful",
    "Energetic",
    "Neutral",
    "Anxious",
    "Stressed",
    "Exhausted",
    "Frustrated",
    "Sad",
    "Overwhelmed",
    "Restless",
]


def sanitize_text(text: Any, max_len: int = 1000) -> str:
    """Sanitize free text input by stripping control characters and trimming length."""
    if text is None:
        return ""
    s = str(text).strip()
    # Remove control characters except standard whitespace
    s = re.sub(r"[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]", "", s)
    # Collapse multiple blank lines
    s = re.sub(r"\r\n|\r", "\n", s)
    return s[:max_len]


def sanitize_tag(tag: str) -> str:
    """Sanitize a single tag string."""
    tag = tag.strip().lower()
    tag = re.sub(r"[^a-z0-9_-]", "", tag)
    return tag[:30]


def validate_date(date_str: str, allow_future: bool = False) -> Tuple[bool, str, Optional[str]]:
    """
    Validate date string conforming strictly to YYYY-MM-DD.
    Returns (is_valid, error_message, cleaned_date_str).
    """
    if not date_str or not isinstance(date_str, str):
        return False, "Date cannot be empty.", None

    s = date_str.strip()
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
    if not match:
        return False, f"Invalid date format '{s}'. Expected YYYY-MM-DD.", None

    year, month, day = map(int, match.groups())
    if year < 2000 or year > 2100:
        return False, f"Year {year} is out of realistic range (2000-2100).", None

    try:
        parsed_date = date(year, month, day)
    except ValueError as e:
        return False, f"Invalid calendar date: {e}.", None

    if not allow_future and parsed_date > date.today():
        return False, f"Date cannot be in the future ({parsed_date} > {date.today()}).", None

    return True, "", parsed_date.strftime("%Y-%m-%d")


def validate_time(time_str: str) -> Tuple[bool, str, Optional[str]]:
    """
    Validate time string conforming to HH:MM (24-hour format).
    Returns (is_valid, error_message, cleaned_time_str).
    """
    if not time_str or not isinstance(time_str, str):
        return False, "Time cannot be empty.", None

    s = time_str.strip()
    match = re.match(r"^(\d{1,2}):(\d{2})$", s)
    if not match:
        return False, f"Invalid time format '{s}'. Expected HH:MM (24-hour).", None

    hours, minutes = map(int, match.groups())
    if hours < 0 or hours > 23:
        return False, f"Hour {hours} out of range (0-23).", None
    if minutes < 0 or minutes > 59:
        return False, f"Minute {minutes} out of range (0-59).", None

    return True, "", f"{hours:02d}:{minutes:02d}"


def validate_int_range(
    val: Any,
    min_val: int = 1,
    max_val: int = 10,
    field_name: str = "Value"
) -> Tuple[bool, str, Optional[int]]:
    """
    Defensively validate integer within boundary constraints.
    Returns (is_valid, error_message, parsed_int).
    """
    if val is None or str(val).strip() == "":
        return False, f"{field_name} cannot be blank.", None

    try:
        f_val = float(val)
        if not f_val.is_integer():
            return False, f"{field_name} must be a whole integer, got '{val}'.", None
        i_val = int(f_val)
    except (ValueError, TypeError):
        return False, f"{field_name} must be a valid integer number, got '{val}'.", None

    if i_val < min_val or i_val > max_val:
        return False, f"{field_name} must be between {min_val} and {max_val} (inclusive). Got {i_val}.", None

    return True, "", i_val


def validate_sleep_hours(val: Any) -> Tuple[bool, str, Optional[float]]:
    """
    Validate sleep hours between 0.0 and 24.0.
    Returns (is_valid, error_message, parsed_float).
    """
    if val is None or str(val).strip() == "":
        return False, "Sleep hours cannot be blank.", None

    try:
        f_val = float(val)
    except (ValueError, TypeError):
        return False, f"Sleep hours must be a valid numeric decimal or integer, got '{val}'.", None

    if f_val < 0.0 or f_val > 24.0:
        return False, f"Sleep hours must be between 0.0 and 24.0. Got {f_val}.", None

    return True, "", round(f_val, 1)


def validate_mood_label(label: Any) -> Tuple[bool, str, Optional[str]]:
    """
    Validate optional mood label. Can be empty/None.
    If provided, checks length and allowed characters.
    """
    if label is None:
        return True, "", None

    s = str(label).strip()
    if not s:
        return True, "", None

    if len(s) > 40:
        return False, f"Mood label cannot exceed 40 characters (got {len(s)}).", None

    if not re.match(r"^[A-Za-z0-9\s\-_'/\(\)]+$", s):
        return False, f"Mood label '{s}' contains invalid special characters.", None

    cleaned = " ".join(s.split()).title()
    return True, "", cleaned


def validate_tags(raw_tags: Any) -> Tuple[bool, str, List[str]]:
    """
    Validate and sanitize tags list or comma-separated string.
    Returns (is_valid, error_message, cleaned_tags_list).
    """
    if raw_tags is None:
        return True, "", []

    tag_list: List[str] = []
    if isinstance(raw_tags, str):
        tokens = raw_tags.replace(";", ",").split(",")
    elif isinstance(raw_tags, (list, tuple, set)):
        tokens = [str(x) for x in raw_tags]
    else:
        tokens = [str(raw_tags)]

    for tok in tokens:
        clean = sanitize_tag(tok)
        if clean and clean not in tag_list:
            tag_list.append(clean)

    if len(tag_list) > 20:
        return False, f"Maximum 20 tags allowed per entry (got {len(tag_list)}).", []

    return True, "", tag_list


def validate_entry_dict(data: Dict[str, Any]) -> Tuple[bool, Dict[str, str], Optional[Dict[str, Any]]]:
    """
    Defensively validate entire dictionary payload for a MoodEntry.
    Returns (is_valid, field_errors_dict, cleaned_data_dict).
    """
    errors: Dict[str, str] = {}
    cleaned: Dict[str, Any] = {}

    # Entry ID
    entry_id = str(data.get("id", "")).strip()
    if not entry_id:
        entry_id = f"MJ-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]}"
    cleaned["id"] = entry_id

    # Date
    v_date, err_date, clean_date = validate_date(str(data.get("date", "")))
    if not v_date:
        errors["date"] = err_date
    else:
        cleaned["date"] = clean_date

    # Time
    time_raw = str(data.get("time", "12:00")).strip() or "12:00"
    v_time, err_time, clean_time = validate_time(time_raw)
    if not v_time:
        errors["time"] = err_time
    else:
        cleaned["time"] = clean_time

    # Mood Score (1-10)
    v_mood, err_mood, clean_mood = validate_int_range(data.get("mood_score"), 1, 10, "Mood Score")
    if not v_mood:
        errors["mood_score"] = err_mood
    else:
        cleaned["mood_score"] = clean_mood

    # Mood Label (Optional)
    v_label, err_label, clean_label = validate_mood_label(data.get("mood_label"))
    if not v_label:
        errors["mood_label"] = err_label
    else:
        cleaned["mood_label"] = clean_label

    # Energy Level (1-10)
    v_energy, err_energy, clean_energy = validate_int_range(data.get("energy_level", 5), 1, 10, "Energy Level")
    if not v_energy:
        errors["energy_level"] = err_energy
    else:
        cleaned["energy_level"] = clean_energy

    # Stress Level (1-10)
    v_stress, err_stress, clean_stress = validate_int_range(data.get("stress_level", 5), 1, 10, "Stress Level")
    if not v_stress:
        errors["stress_level"] = err_stress
    else:
        cleaned["stress_level"] = clean_stress

    # Sleep Hours (0.0 - 24.0)
    v_sleep, err_sleep, clean_sleep = validate_sleep_hours(data.get("sleep_hours", 7.0))
    if not v_sleep:
        errors["sleep_hours"] = err_sleep
    else:
        cleaned["sleep_hours"] = clean_sleep

    # Tags
    v_tags, err_tags, clean_tags = validate_tags(data.get("tags", []))
    if not v_tags:
        errors["tags"] = err_tags
    else:
        cleaned["tags"] = clean_tags

    # Notes
    cleaned["notes"] = sanitize_text(data.get("notes", ""), max_len=1500)

    # Timestamps
    cleaned["created_at"] = str(data.get("created_at") or datetime.now().isoformat())
    cleaned["updated_at"] = str(data.get("updated_at") or datetime.now().isoformat())

    is_valid = len(errors) == 0
    return is_valid, errors, (cleaned if is_valid else None)
