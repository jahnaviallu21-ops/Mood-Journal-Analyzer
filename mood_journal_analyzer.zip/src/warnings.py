"""
Threshold Warning Indicators and Anomaly Detection Engine.
Detects overdue check-ins, severe mood drops, prolonged stress breaches,
sleep deprivation alerts, and burnout risk indicators.
"""

from datetime import datetime, date, timedelta
from typing import List, Optional
from src.models import MoodEntry, WarningAlert


class WarningEngine:
    """Evaluates mood journal records against health & wellbeing safety thresholds."""

    @staticmethod
    def evaluate_all(entries: List[MoodEntry], reference_date: Optional[date] = None) -> List[WarningAlert]:
        """
        Run all warning checks against entries chronologically.
        Returns a list of structured WarningAlert objects ordered by severity.
        """
        alerts: List[WarningAlert] = []
        if not entries:
            alerts.append(WarningAlert(
                severity="INFO",
                category="MISSED_ENTRY",
                message="No journal entries recorded yet.",
                date=str(date.today()),
                recommendation="Record your first entry to begin tracking your mood patterns and wellbeing trends."
            ))
            return alerts

        sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))

        ref = reference_date or date.today()

        # 1. Check for Overdue Check-in / Tracking Gap
        latest_entry_date_str = sorted_entries[-1].date
        try:
            latest_date = datetime.strptime(latest_entry_date_str, "%Y-%m-%d").date()
            gap_days = (ref - latest_date).days
            if gap_days >= 3:
                alerts.append(WarningAlert(
                    severity="WARNING",
                    category="MISSED_ENTRY",
                    message=f"Overdue Entry: No mood check-in recorded for {gap_days} consecutive days (last entry: {latest_entry_date_str}).",
                    date=str(ref),
                    recommendation="Consistency provides clearer insights. Take 60 seconds to log today's mood."
                ))
            elif gap_days == 2:
                alerts.append(WarningAlert(
                    severity="INFO",
                    category="MISSED_ENTRY",
                    message=f"Check-in Reminder: Yesterday was missed. Last entry was {latest_entry_date_str}.",
                    date=str(ref),
                    recommendation="Log a quick journal check-in to preserve your tracking streak."
                ))
        except Exception:
            pass

        # 2. Check for Acute Mood Drops (>= 4 point drop between adjacent entries)
        for i in range(1, len(sorted_entries)):
            prev_entry = sorted_entries[i - 1]
            curr_entry = sorted_entries[i]

            try:
                d1 = datetime.strptime(prev_entry.date, "%Y-%m-%d").date()
                d2 = datetime.strptime(curr_entry.date, "%Y-%m-%d").date()
                day_delta = (d2 - d1).days
            except Exception:
                day_delta = 1

            if day_delta <= 2:
                drop = prev_entry.mood_score - curr_entry.mood_score
                if drop >= 4:
                    alerts.append(WarningAlert(
                        severity="WARNING",
                        category="MOOD_DROP",
                        message=f"Acute Mood Drop: Score plummeted by {drop} points on {curr_entry.date} (from {prev_entry.mood_score}/10 to {curr_entry.mood_score}/10).",
                        date=curr_entry.date,
                        recommendation="Consider reflecting on recent triggers or stressors in your journal notes."
                    ))

        # 3. Check for Prolonged High Stress (stress >= 8 for 2+ consecutive records)
        consecutive_high_stress = 0
        stress_streak_start = None
        for e in sorted_entries:
            if e.stress_level >= 8:
                consecutive_high_stress += 1
                if consecutive_high_stress == 1:
                    stress_streak_start = e.date
                if consecutive_high_stress >= 3:
                    alerts.append(WarningAlert(
                        severity="CRITICAL",
                        category="PROLONGED_STRESS",
                        message=f"High Stress Threshold Breach: Stress level has remained at or above 8/10 for {consecutive_high_stress} consecutive entries (since {stress_streak_start}).",
                        date=e.date,
                        recommendation="Sustained severe stress impacts cognitive clarity and immunity. Consider taking intentional breaks, breathwork, or discussing workload with your mentor."
                    ))
            else:
                consecutive_high_stress = 0
                stress_streak_start = None

        # 4. Check for Sleep Deficit (< 5.0 hours of sleep)
        recent_sleep_deprived = [e for e in sorted_entries[-5:] if e.sleep_hours < 5.0]
        if len(recent_sleep_deprived) >= 2:
            alerts.append(WarningAlert(
                severity="WARNING",
                category="SLEEP_DEFICIT",
                message=f"Sleep Deficit Detected: {len(recent_sleep_deprived)} out of your last 5 entries recorded under 5 hours of sleep.",
                date=sorted_entries[-1].date,
                recommendation="Sub-optimal sleep compounds emotional reactivity. Prioritize a consistent wind-down routine tonight."
            ))

        # 5. Check for Critical Burnout Risk (Low mood <= 3 AND High stress >= 8 together)
        burnout_entries = [e for e in sorted_entries[-3:] if e.mood_score <= 3 and e.stress_level >= 8]
        if burnout_entries:
            latest_b = burnout_entries[-1]
            alerts.append(WarningAlert(
                severity="CRITICAL",
                category="BURNOUT_RISK",
                message=f"Critical Burnout Risk Alert: Concurrent low mood ({latest_b.mood_score}/10) and severe stress ({latest_b.stress_level}/10) detected on {latest_b.date}.",
                date=latest_b.date,
                recommendation="Urgent: Step away from taxing tasks. Engage in grounding activities and reach out to a trusted peer, counselor, or supervisor."
            ))

        # 6. Check for Persistent Low Mood (Last 3 entries avg mood <= 3.5)
        if len(sorted_entries) >= 3:
            recent_3 = sorted_entries[-3:]
            avg_recent = sum(e.mood_score for e in recent_3) / 3
            if avg_recent <= 3.5:
                alerts.append(WarningAlert(
                    severity="WARNING",
                    category="PERSISTENT_LOW_MOOD",
                    message=f"Persistent Low Mood Flag: Average mood over the last 3 entries is {avg_recent:.1f}/10.",
                    date=recent_3[-1].date,
                    recommendation="Prolonged depressive or low energy episodes benefit from gentle physical movement and social connection."
                ))

        # Sort alerts: CRITICAL first, then WARNING, then INFO
        severity_rank = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
        alerts.sort(key=lambda a: severity_rank.get(a.severity, 3))
        return alerts
