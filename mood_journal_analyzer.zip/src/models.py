"""
Domain models and dataclasses for Mood Journal Analyzer.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any


@dataclass
class MoodEntry:
    """Represents a single mood journal entry."""
    id: str
    date: str  # YYYY-MM-DD
    time: str  # HH:MM
    mood_score: int  # 1 to 10 scale
    mood_label: Optional[str] = None  # Optional mood label (e.g., Joyful, Calm, Anxious)
    energy_level: int = 5  # 1 to 10 scale
    stress_level: int = 5  # 1 to 10 scale
    sleep_hours: float = 7.0  # 0.0 to 24.0 hours
    tags: List[str] = field(default_factory=list)
    notes: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert entry to dictionary for JSON persistence."""
        return {
            "id": self.id,
            "date": self.date,
            "time": self.time,
            "mood_score": self.mood_score,
            "mood_label": self.mood_label or "",
            "energy_level": self.energy_level,
            "stress_level": self.stress_level,
            "sleep_hours": self.sleep_hours,
            "tags": self.tags,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MoodEntry":
        """Reconstruct MoodEntry from dictionary."""
        tags = data.get("tags", [])
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",") if t.strip()]

        raw_label = data.get("mood_label")
        mood_label = raw_label.strip() if raw_label and str(raw_label).strip() else None

        return cls(
            id=str(data.get("id", "")),
            date=str(data.get("date", "")),
            time=str(data.get("time", "12:00")),
            mood_score=int(data.get("mood_score", 5)),
            mood_label=mood_label,
            energy_level=int(data.get("energy_level", 5)),
            stress_level=int(data.get("stress_level", 5)),
            sleep_hours=float(data.get("sleep_hours", 7.0)),
            tags=tags,
            notes=str(data.get("notes", "")),
            created_at=str(data.get("created_at", datetime.now().isoformat())),
            updated_at=str(data.get("updated_at", datetime.now().isoformat())),
        )

    def to_csv_row(self) -> Dict[str, str]:
        """Convert entry to flat dictionary for CSV serialization."""
        return {
            "id": self.id,
            "date": self.date,
            "time": self.time,
            "mood_score": str(self.mood_score),
            "mood_label": self.mood_label or "",
            "energy_level": str(self.energy_level),
            "stress_level": str(self.stress_level),
            "sleep_hours": f"{self.sleep_hours:.1f}",
            "tags": ";".join(self.tags),
            "notes": self.notes.replace("\n", " "),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_csv_row(cls, row: Dict[str, str]) -> "MoodEntry":
        """Reconstruct MoodEntry from CSV row dictionary."""
        raw_tags = row.get("tags", "")
        tags = [t.strip() for t in raw_tags.split(";") if t.strip()] if raw_tags else []

        raw_label = row.get("mood_label", "").strip()
        mood_label = raw_label if raw_label else None

        return cls(
            id=row.get("id", "").strip(),
            date=row.get("date", "").strip(),
            time=row.get("time", "12:00").strip(),
            mood_score=int(row.get("mood_score", 5)),
            mood_label=mood_label,
            energy_level=int(row.get("energy_level", 5)),
            stress_level=int(row.get("stress_level", 5)),
            sleep_hours=float(row.get("sleep_hours", 7.0)),
            tags=tags,
            notes=row.get("notes", "").strip(),
            created_at=row.get("created_at", datetime.now().isoformat()),
            updated_at=row.get("updated_at", datetime.now().isoformat()),
        )


@dataclass
class FilterCriteria:
    """Filter parameters for querying mood entries."""
    keyword: Optional[str] = None
    mood_label: Optional[str] = None
    min_mood_score: Optional[int] = None
    max_mood_score: Optional[int] = None
    start_date: Optional[str] = None  # YYYY-MM-DD
    end_date: Optional[str] = None    # YYYY-MM-DD
    min_stress: Optional[int] = None
    max_stress: Optional[int] = None
    tag: Optional[str] = None


@dataclass
class AggregateSummary:
    """Executive metrics and aggregated trends."""
    total_entries: int = 0
    avg_mood: float = 0.0
    min_mood: int = 0
    max_mood: int = 0
    avg_energy: float = 0.0
    avg_stress: float = 0.0
    avg_sleep: float = 0.0
    mood_label_counts: Dict[str, int] = field(default_factory=dict)
    mood_volatility: float = 0.0
    mood_trend: str = "Insufficient Data"
    wellness_status: str = "Unassessed"
    wellness_indicator_color: str = "WHITE"
    best_day_of_week: str = "N/A"
    worst_day_of_week: str = "N/A"
    current_streak_days: int = 0
    longest_streak_days: int = 0
    days_logged: int = 0
    date_range_str: str = "N/A"


@dataclass
class WarningAlert:
    """Threshold warning flag or anomaly detection alert."""
    severity: str  # "INFO", "WARNING", "CRITICAL"
    category: str  # "MISSED_ENTRY", "MOOD_DROP", "PROLONGED_STRESS", "SLEEP_DEFICIT", "BURNOUT_RISK"
    message: str
    date: Optional[str] = None
    recommendation: str = ""
