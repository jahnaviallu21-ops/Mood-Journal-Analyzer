"""
Modern, Professional Graphical User Interface (GUI) for Mood Journal Analyzer.
Engineered with Tkinter and ttk, featuring a soothing wellness color palette,
KPI summary cards, embedded Matplotlib interactive visualizations,
guided entry forms, search/filter data tables, and one-click report exports.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, date
from pathlib import Path
from typing import Optional, List, Dict, Any

from src.models import MoodEntry, FilterCriteria
from src.validator import (
    validate_date,
    validate_time,
    validate_int_range,
    validate_sleep_hours,
    validate_mood_label,
    validate_tags,
    sanitize_text,
    STANDARD_MOOD_LABELS,
)
from src.storage import StorageManager
from src.analytics import generate_executive_summary, filter_entries
from src.warnings import WarningEngine
from src.plotter import MoodPlotter, PALETTE
from src.exporters import ReportExporter
from src.importer import BulkImporter

# Calming, Modern Health & Wellbeing Palette
THEME = {
    "bg_main": "#F1F5F9",        # Light slate background
    "bg_card": "#FFFFFF",        # Crisp card white
    "primary": "#3B82F6",        # Serene Blue
    "primary_dark": "#1D4ED8",   # Deep Indigo Blue
    "secondary": "#0D9488",      # Calming Teal
    "success": "#10B981",        # Emerald Green (Thriving)
    "warning": "#F59E0B",        # Warm Amber
    "danger": "#EF4444",         # Coral Red
    "text_dark": "#0F172A",      # Slate Charcoal
    "text_muted": "#64748B",     # Cool Slate
    "border": "#CBD5E1",         # Light Border
}


class MoodJournalGUI(tk.Tk):
    """Main application window for Mood Journal Analyzer."""

    def __init__(self, storage: Optional[StorageManager] = None):
        super().__init__()

        self.storage = storage or StorageManager()
        self.plotter = MoodPlotter()
        self.exporter = ReportExporter()
        self.importer = BulkImporter()

        self.title("🌿 Mood Journal Analyzer - Wellbeing Dashboard")
        self.geometry("1120x760")
        self.minsize(980, 680)
        self.configure(bg=THEME["bg_main"])

        # Configure TTK Styles
        self._setup_styles()

        # Build Main Layout
        self._build_header()
        self._build_notebook_tabs()
        self._build_status_bar()

        # Load initial data
        self.refresh_dashboard()
        self.refresh_table()

    def _setup_styles(self) -> None:
        """Configure modern ttk widgets styling."""
        style = ttk.Style(self)
        style.theme_use("clam")

        # Configure Notebook Tab Bar
        style.configure("TNotebook", background=THEME["bg_main"], borderwidth=0)
        style.configure(
            "TNotebook.Tab",
            background="#E2E8F0",
            foreground=THEME["text_dark"],
            padding=[18, 8],
            font=("Segoe UI", 10, "bold"),
            borderwidth=0,
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", THEME["primary_dark"])],
            foreground=[("selected", "#FFFFFF")],
        )

        # Treeview styling
        style.configure(
            "Treeview",
            background="#FFFFFF",
            foreground=THEME["text_dark"],
            rowheight=26,
            fieldbackground="#FFFFFF",
            font=("Segoe UI", 9),
            borderwidth=0,
        )
        style.configure(
            "Treeview.Heading",
            background="#E2E8F0",
            foreground=THEME["text_dark"],
            font=("Segoe UI", 9, "bold"),
            relief="flat",
        )
        style.map("Treeview", background=[("selected", "#DBEAFE")], foreground=[("selected", THEME["primary_dark"])])

    def _build_header(self) -> None:
        """Build branded modern header bar."""
        header_frame = tk.Frame(self, bg=THEME["primary_dark"], height=68)
        header_frame.pack(fill=tk.X, side=tk.TOP)
        header_frame.pack_propagate(False)

        title_label = tk.Label(
            header_frame,
            text="🌿 MOOD JOURNAL ANALYZER",
            font=("Segoe UI", 15, "bold"),
            fg="#FFFFFF",
            bg=THEME["primary_dark"],
        )
        title_label.pack(side=tk.LEFT, padx=22, pady=(12, 0), anchor="w")

        subtitle_label = tk.Label(
            header_frame,
            text="Health & Wellbeing Analytics • Pattern Tracking • Defensive Data Persistence",
            font=("Segoe UI", 9),
            fg="#93C5FD",
            bg=THEME["primary_dark"],
        )
        subtitle_label.place(x=22, y=38)

        # Quick Refresh & Export buttons in header
        btn_frame = tk.Frame(header_frame, bg=THEME["primary_dark"])
        btn_frame.pack(side=tk.RIGHT, padx=20, pady=16)

        refresh_btn = tk.Button(
            btn_frame,
            text="🔄 Refresh Data",
            font=("Segoe UI", 9, "bold"),
            bg="#2563EB",
            fg="#FFFFFF",
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2",
            command=self.on_refresh_all,
        )
        refresh_btn.pack(side=tk.LEFT, padx=6)

        export_btn = tk.Button(
            btn_frame,
            text="📤 Quick Export",
            font=("Segoe UI", 9, "bold"),
            bg=THEME["secondary"],
            fg="#FFFFFF",
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2",
            command=self.on_quick_export,
        )
        export_btn.pack(side=tk.LEFT, padx=6)

    def _build_notebook_tabs(self) -> None:
        """Create tabbed interface views."""
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=18, pady=(14, 8))

        # Tab 1: Dashboard
        self.tab_dashboard = tk.Frame(self.notebook, bg=THEME["bg_main"])
        self.notebook.add(self.tab_dashboard, text="  📊 Overview & Dashboard  ")
        self._build_dashboard_tab()

        # Tab 2: New Entry Form
        self.tab_form = tk.Frame(self.notebook, bg=THEME["bg_main"])
        self.notebook.add(self.tab_form, text="  📝 Record New Entry  ")
        self._build_entry_form_tab()

        # Tab 3: History & Search Table
        self.tab_history = tk.Frame(self.notebook, bg=THEME["bg_main"])
        self.notebook.add(self.tab_history, text="  🔍 Journal Log & Search  ")
        self._build_history_tab()

        # Tab 4: Warnings & Alerts
        self.tab_warnings = tk.Frame(self.notebook, bg=THEME["bg_main"])
        self.notebook.add(self.tab_warnings, text="  ⚠️  Warning Flags & Audit  ")
        self._build_warnings_tab()

        # Tab 5: Data Management & Ingestion
        self.tab_data_mgmt = tk.Frame(self.notebook, bg=THEME["bg_main"])
        self.notebook.add(self.tab_data_mgmt, text="  ⚙️  Data Tools & CSV Ingestion  ")
        self._build_data_mgmt_tab()

    def _build_status_bar(self) -> None:
        """Create bottom status indicator bar."""
        self.status_bar = tk.Label(
            self,
            text="Ready. System persistence initialized.",
            font=("Segoe UI", 9),
            fg=THEME["text_muted"],
            bg="#E2E8F0",
            anchor="w",
            padx=16,
            pady=4,
        )
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)

    def set_status(self, text: str) -> None:
        """Update status bar message."""
        self.status_bar.config(text=f"• {text}  |  {datetime.now().strftime('%H:%M:%S')}")

    # =========================================================================
    # TAB 1: Dashboard & Visualizations
    # =========================================================================
    def _build_dashboard_tab(self) -> None:
        """Construct KPI metric cards and embedded visual chart canvas."""
        # Top KPI Cards Frame
        kpi_frame = tk.Frame(self.tab_dashboard, bg=THEME["bg_main"])
        kpi_frame.pack(fill=tk.X, padx=12, pady=(12, 8))

        self.card_avg_mood = self._create_kpi_card(kpi_frame, "AVERAGE MOOD", "0.0 / 10", THEME["primary"])
        self.card_wellness = self._create_kpi_card(kpi_frame, "WELLNESS STATUS", "Assessing...", THEME["success"])
        self.card_streak = self._create_kpi_card(kpi_frame, "ACTIVE STREAK", "0 days", THEME["secondary"])
        self.card_sleep = self._create_kpi_card(kpi_frame, "AVG SLEEP", "0.0 hrs", THEME["warning"])
        self.card_total = self._create_kpi_card(kpi_frame, "TOTAL LOGGED", "0 entries", THEME["text_dark"])

        # Visual Plot Display Frame
        self.plot_container = tk.Frame(self.tab_dashboard, bg=THEME["bg_card"], bd=1, relief="solid")
        self.plot_container.pack(fill=tk.BOTH, expand=True, padx=12, pady=(4, 12))

        self.canvas_label = tk.Label(
            self.plot_container,
            text="Visual Analytics Rendering...",
            font=("Segoe UI", 11),
            fg=THEME["text_muted"],
            bg=THEME["bg_card"],
        )
        self.canvas_label.pack(expand=True)

    def _create_kpi_card(self, parent: tk.Widget, title: str, default_val: str, accent_color: str) -> Dict[str, tk.Label]:
        """Create a rounded-style KPI metric card."""
        card = tk.Frame(parent, bg=THEME["bg_card"], bd=1, relief="solid", padx=14, pady=10)
        card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=6)

        t_lbl = tk.Label(card, text=title, font=("Segoe UI", 8, "bold"), fg=THEME["text_muted"], bg=THEME["bg_card"])
        t_lbl.pack(anchor="w")

        v_lbl = tk.Label(card, text=default_val, font=("Segoe UI", 14, "bold"), fg=accent_color, bg=THEME["bg_card"])
        v_lbl.pack(anchor="w", pady=(3, 0))

        sub_lbl = tk.Label(card, text="", font=("Segoe UI", 8), fg=THEME["text_muted"], bg=THEME["bg_card"])
        sub_lbl.pack(anchor="w")

        return {"title": t_lbl, "val": v_lbl, "sub": sub_lbl}

    def refresh_dashboard(self) -> None:
        """Recalculate summary metrics and embed Matplotlib figure."""
        entries, _ = self.storage.load_entries()
        summary = generate_executive_summary(entries)

        # Update KPI Cards
        self.card_avg_mood["val"].config(text=f"{summary.avg_mood:.2f} / 10")
        self.card_avg_mood["sub"].config(text=f"Range: {summary.min_mood} - {summary.max_mood} (σ = {summary.mood_volatility:.2f})")

        self.card_wellness["val"].config(text=summary.wellness_status.split("(")[0].strip())
        self.card_wellness["sub"].config(text=f"Trend: {summary.mood_trend}")

        self.card_streak["val"].config(text=f"{summary.current_streak_days} days")
        self.card_streak["sub"].config(text=f"Longest: {summary.longest_streak_days} days")

        self.card_sleep["val"].config(text=f"{summary.avg_sleep:.1f} hrs")
        self.card_sleep["sub"].config(text=f"Avg Stress: {summary.avg_stress:.1f} / 10")

        self.card_total["val"].config(text=f"{summary.total_entries} records")
        self.card_total["sub"].config(text=f"Span: {summary.date_range_str}")

        # Render Chart in Canvas
        self._render_embedded_plot(entries)

    def _render_embedded_plot(self, entries: List[MoodEntry]) -> None:
        """Embed Matplotlib chart or Tkinter Canvas chart."""
        for widget in self.plot_container.winfo_children():
            widget.destroy()

        if not entries:
            no_data = tk.Label(
                self.plot_container,
                text="No entries recorded yet. Record your first entry to generate visual trends.",
                font=("Segoe UI", 11),
                fg=THEME["text_muted"],
                bg=THEME["bg_card"],
            )
            no_data.pack(expand=True)
            return

        try:
            import matplotlib
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

            sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))
            indices = list(range(len(sorted_entries)))
            moods = [e.mood_score for e in sorted_entries]
            stress = [e.stress_level for e in sorted_entries]
            dates = [e.date[5:] for e in sorted_entries]

            # Create clean embedded 2-subplot figure
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.2), facecolor="#FFFFFF")

            # Left: Mood & Stress Over Time
            ax1.set_facecolor("#F8FAFC")
            ax1.plot(indices, moods, marker="o", color="#2563EB", linewidth=2.2, label="Mood (1-10)")
            ax1.plot(indices, stress, marker="s", color="#EF4444", linewidth=1.8, linestyle="--", label="Stress (1-10)")
            ax1.set_title("Longitudinal Mood & Stress Trajectory", fontsize=10, fontweight="bold", color="#0F172A")
            ax1.set_ylim(0.5, 10.5)
            ax1.set_xticks(indices[::max(1, len(indices) // 7)])
            ax1.set_xticklabels([dates[i] for i in indices[::max(1, len(indices) // 7)]], rotation=30, fontsize=8)
            ax1.grid(True, linestyle="--", alpha=0.5, color="#E2E8F0")
            ax1.legend(loc="upper left", fontsize=8)

            # Right: Mood Labels Distribution
            ax2.set_facecolor("#F8FAFC")
            lbl_counts: Dict[str, int] = {}
            for e in sorted_entries:
                l = e.mood_label if e.mood_label else "Unlabeled"
                lbl_counts[l] = lbl_counts.get(l, 0) + 1

            top = sorted(lbl_counts.items(), key=lambda x: x[1], reverse=True)[:6]
            labels = [x[0] for x in top]
            counts = [x[1] for x in top]
            colors = ["#3B82F6", "#10B981", "#F59E0B", "#8B5CF6", "#06B6D4", "#94A3B8"][:len(labels)]

            ax2.pie(
                counts,
                labels=labels,
                autopct="%1.1f%%",
                startangle=140,
                colors=colors,
                wedgeprops={"edgecolor": "white", "linewidth": 1.5, "width": 0.6}
            )
            ax2.set_title("Mood Label Frequency Distribution", fontsize=10, fontweight="bold", color="#0F172A")

            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=self.plot_container)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        except Exception as e:
            # Fallback text
            fallback_lbl = tk.Label(
                self.plot_container,
                text=f"Visual Plot Display Notice: {e}\n(Terminal ASCII trend is fully active in CLI mode)",
                font=("Segoe UI", 10),
                fg=THEME["text_muted"],
                bg=THEME["bg_card"],
            )
            fallback_lbl.pack(expand=True)

    # =========================================================================
    # TAB 2: Record New Entry
    # =========================================================================
    def _build_entry_form_tab(self) -> None:
        """Construct defensive input form for adding new entries."""
        outer = tk.Frame(self.tab_form, bg=THEME["bg_main"])
        outer.pack(fill=tk.BOTH, expand=True, padx=28, pady=18)

        card = tk.Frame(outer, bg=THEME["bg_card"], bd=1, relief="solid", padx=28, pady=22)
        card.pack(fill=tk.BOTH, expand=True)

        form_title = tk.Label(
            card,
            text="Record a New Mood & Wellbeing Check-in",
            font=("Segoe UI", 13, "bold"),
            fg=THEME["text_dark"],
            bg=THEME["bg_card"],
        )
        form_title.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 16))

        # Row 1: Date & Time
        tk.Label(card, text="Date (YYYY-MM-DD):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=1, column=0, sticky="w", pady=6)
        self.entry_date_var = tk.StringVar(value=date.today().strftime("%Y-%m-%d"))
        tk.Entry(card, textvariable=self.entry_date_var, width=18, font=("Segoe UI", 10)).grid(row=1, column=1, sticky="w", padx=10, pady=6)

        tk.Label(card, text="Time (HH:MM 24h):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=1, column=2, sticky="w", pady=6)
        self.entry_time_var = tk.StringVar(value=datetime.now().strftime("%H:%M"))
        tk.Entry(card, textvariable=self.entry_time_var, width=18, font=("Segoe UI", 10)).grid(row=1, column=3, sticky="w", padx=10, pady=6)

        # Row 2: Mood Score & Mood Label
        tk.Label(card, text="Mood Score (1-10):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=2, column=0, sticky="w", pady=8)
        self.mood_slider = tk.Scale(card, from_=1, to=10, orient=tk.HORIZONTAL, length=180, bg=THEME["bg_card"], highlightthickness=0)
        self.mood_slider.set(7)
        self.mood_slider.grid(row=2, column=1, sticky="w", padx=10, pady=8)

        tk.Label(card, text="Mood Label (Optional):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=2, column=2, sticky="w", pady=8)
        self.mood_label_combo = ttk.Combobox(card, values=["", *STANDARD_MOOD_LABELS], width=16, font=("Segoe UI", 10))
        self.mood_label_combo.set("Calm")
        self.mood_label_combo.grid(row=2, column=3, sticky="w", padx=10, pady=8)

        # Row 3: Energy & Stress
        tk.Label(card, text="Energy Level (1-10):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=3, column=0, sticky="w", pady=8)
        self.energy_slider = tk.Scale(card, from_=1, to=10, orient=tk.HORIZONTAL, length=180, bg=THEME["bg_card"], highlightthickness=0)
        self.energy_slider.set(6)
        self.energy_slider.grid(row=3, column=1, sticky="w", padx=10, pady=8)

        tk.Label(card, text="Stress Level (1-10):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=3, column=2, sticky="w", pady=8)
        self.stress_slider = tk.Scale(card, from_=1, to=10, orient=tk.HORIZONTAL, length=180, bg=THEME["bg_card"], highlightthickness=0)
        self.stress_slider.set(4)
        self.stress_slider.grid(row=3, column=3, sticky="w", padx=10, pady=8)

        # Row 4: Sleep Hours & Tags
        tk.Label(card, text="Sleep Hours (0-24h):", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=4, column=0, sticky="w", pady=8)
        self.sleep_var = tk.StringVar(value="7.5")
        tk.Entry(card, textvariable=self.sleep_var, width=18, font=("Segoe UI", 10)).grid(row=4, column=1, sticky="w", padx=10, pady=8)

        tk.Label(card, text="Activity Tags:", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=4, column=2, sticky="w", pady=8)
        self.tags_var = tk.StringVar(value="work, morning")
        tk.Entry(card, textvariable=self.tags_var, width=22, font=("Segoe UI", 10)).grid(row=4, column=3, sticky="w", padx=10, pady=8)

        # Row 5: Reflection Notes
        tk.Label(card, text="Journal Notes:", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).grid(row=5, column=0, sticky="nw", pady=(10, 0))
        self.notes_text = tk.Text(card, height=4, width=65, font=("Segoe UI", 10), bd=1, relief="solid")
        self.notes_text.grid(row=5, column=1, columnspan=3, sticky="w", padx=10, pady=(10, 16))

        # Buttons Row
        btn_box = tk.Frame(card, bg=THEME["bg_card"])
        btn_box.grid(row=6, column=1, columnspan=3, sticky="w", padx=10)

        submit_btn = tk.Button(
            btn_box,
            text="💾 Save Journal Entry",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["success"],
            fg="#FFFFFF",
            relief="flat",
            padx=18,
            pady=8,
            cursor="hand2",
            command=self.on_submit_entry,
        )
        submit_btn.pack(side=tk.LEFT, padx=(0, 12))

        clear_btn = tk.Button(
            btn_box,
            text="Clear Form",
            font=("Segoe UI", 9),
            bg="#E2E8F0",
            fg=THEME["text_dark"],
            relief="flat",
            padx=14,
            pady=8,
            cursor="hand2",
            command=self.on_clear_form,
        )
        clear_btn.pack(side=tk.LEFT)

    def on_submit_entry(self) -> None:
        """Validate form inputs defensively and persist."""
        d_val = self.entry_date_var.get().strip()
        t_val = self.entry_time_var.get().strip()
        s_val = self.sleep_var.get().strip()
        m_score = self.mood_slider.get()
        lbl_val = self.mood_label_combo.get().strip() or None
        e_score = self.energy_slider.get()
        str_score = self.stress_slider.get()
        t_val_tags = self.tags_var.get().strip()
        notes_raw = self.notes_text.get("1.0", tk.END).strip()

        # Defensive Validations
        v_date, err_date, clean_date = validate_date(d_val)
        if not v_date:
            messagebox.showerror("Validation Error", f"Date Error: {err_date}")
            return

        v_time, err_time, clean_time = validate_time(t_val)
        if not v_time:
            messagebox.showerror("Validation Error", f"Time Error: {err_time}")
            return

        v_sleep, err_sleep, clean_sleep = validate_sleep_hours(s_val)
        if not v_sleep:
            messagebox.showerror("Validation Error", f"Sleep Error: {err_sleep}")
            return

        v_lbl, err_lbl, clean_lbl = validate_mood_label(lbl_val)
        if not v_lbl:
            messagebox.showerror("Validation Error", f"Mood Label Error: {err_lbl}")
            return

        _, _, clean_tags = validate_tags(t_val_tags)
        clean_notes = sanitize_text(notes_raw, max_len=1500)

        entry_id = f"MJ-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]}"

        new_entry = MoodEntry(
            id=entry_id,
            date=clean_date,
            time=clean_time,
            mood_score=m_score,
            mood_label=clean_lbl,
            energy_level=e_score,
            stress_level=str_score,
            sleep_hours=clean_sleep,
            tags=clean_tags,
            notes=clean_notes,
        )

        success, msg = self.storage.add_entry(new_entry)
        if success:
            messagebox.showinfo("Success", f"{msg}\nState successfully preserved to CSV & JSON.")
            self.set_status(f"Saved entry {new_entry.id}")
            self.on_clear_form()
            self.refresh_dashboard()
            self.refresh_table()
            self.refresh_warnings()
        else:
            messagebox.showerror("Storage Error", f"Could not save entry: {msg}")

    def on_clear_form(self) -> None:
        """Reset form fields to default."""
        self.entry_date_var.set(date.today().strftime("%Y-%m-%d"))
        self.entry_time_var.set(datetime.now().strftime("%H:%M"))
        self.mood_slider.set(7)
        self.mood_label_combo.set("Calm")
        self.energy_slider.set(6)
        self.stress_slider.set(4)
        self.sleep_var.set("7.5")
        self.tags_var.set("")
        self.notes_text.delete("1.0", tk.END)

    # =========================================================================
    # TAB 3: History & Search Table
    # =========================================================================
    def _build_history_tab(self) -> None:
        """Construct interactive data table with query filters."""
        filter_bar = tk.Frame(self.tab_history, bg=THEME["bg_card"], bd=1, relief="solid", padx=12, pady=10)
        filter_bar.pack(fill=tk.X, padx=12, pady=(12, 6))

        tk.Label(filter_bar, text="Keyword Search:", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).pack(side=tk.LEFT, padx=(0, 4))
        self.search_kw_var = tk.StringVar()
        kw_entry = tk.Entry(filter_bar, textvariable=self.search_kw_var, width=16, font=("Segoe UI", 9))
        kw_entry.pack(side=tk.LEFT, padx=(0, 12))
        kw_entry.bind("<KeyRelease>", lambda e: self.on_filter_changed())

        tk.Label(filter_bar, text="Label:", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).pack(side=tk.LEFT, padx=(0, 4))
        self.filter_lbl_var = tk.StringVar(value="All")
        lbl_combo = ttk.Combobox(filter_bar, textvariable=self.filter_lbl_var, values=["All", "Unlabeled", *STANDARD_MOOD_LABELS], width=11, state="readonly")
        lbl_combo.pack(side=tk.LEFT, padx=(0, 12))
        lbl_combo.bind("<<ComboboxSelected>>", lambda e: self.on_filter_changed())

        tk.Label(filter_bar, text="Min Mood:", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card"]).pack(side=tk.LEFT, padx=(0, 4))
        self.filter_min_mood = ttk.Combobox(filter_bar, values=["Any", "1", "3", "5", "7", "9"], width=6, state="readonly")
        self.filter_min_mood.set("Any")
        self.filter_min_mood.pack(side=tk.LEFT, padx=(0, 12))
        self.filter_min_mood.bind("<<ComboboxSelected>>", lambda e: self.on_filter_changed())

        reset_filter_btn = tk.Button(filter_bar, text="Reset Filters", font=("Segoe UI", 8), bg="#E2E8F0", relief="flat", command=self.on_reset_filters)
        reset_filter_btn.pack(side=tk.LEFT, padx=6)

        # Table actions
        del_btn = tk.Button(filter_bar, text="🗑️ Delete Selected", font=("Segoe UI", 8, "bold"), bg=THEME["danger"], fg="#FFFFFF", relief="flat", command=self.on_delete_selected)
        del_btn.pack(side=tk.RIGHT, padx=4)

        # Table Frame
        tbl_frame = tk.Frame(self.tab_history, bg=THEME["bg_card"])
        tbl_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        columns = ("id", "date", "time", "mood", "label", "energy", "stress", "sleep", "tags", "notes")
        self.tree = ttk.Treeview(tbl_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="Entry ID")
        self.tree.heading("date", text="Date")
        self.tree.heading("time", text="Time")
        self.tree.heading("mood", text="Mood")
        self.tree.heading("label", text="Label")
        self.tree.heading("energy", text="Energy")
        self.tree.heading("stress", text="Stress")
        self.tree.heading("sleep", text="Sleep")
        self.tree.heading("tags", text="Tags")
        self.tree.heading("notes", text="Reflection Notes")

        self.tree.column("id", width=110, anchor="center")
        self.tree.column("date", width=85, anchor="center")
        self.tree.column("time", width=55, anchor="center")
        self.tree.column("mood", width=55, anchor="center")
        self.tree.column("label", width=95, anchor="w")
        self.tree.column("energy", width=55, anchor="center")
        self.tree.column("stress", width=55, anchor="center")
        self.tree.column("sleep", width=60, anchor="center")
        self.tree.column("tags", width=120, anchor="w")
        self.tree.column("notes", width=340, anchor="w")

        # Scrollbar
        scroll_y = ttk.Scrollbar(tbl_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll_y.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

    def refresh_table(self, filtered_records: Optional[List[MoodEntry]] = None) -> None:
        """Populate the table with records."""
        for row in self.tree.get_children():
            self.tree.delete(row)

        if filtered_records is None:
            records, _ = self.storage.load_entries()
        else:
            records = filtered_records

        for e in records:
            lbl = e.mood_label if e.mood_label else "-"
            tags_str = ", ".join(e.tags) if e.tags else "-"
            note = e.notes.replace("\n", " ")
            self.tree.insert(
                "",
                tk.END,
                values=(e.id, e.date, e.time, f"{e.mood_score}/10", lbl, f"{e.energy_level}/10", f"{e.stress_level}/10", f"{e.sleep_hours:.1f}h", tags_str, note)
            )

    def on_filter_changed(self) -> None:
        """Re-filter records on input change."""
        entries, _ = self.storage.load_entries()
        kw = self.search_kw_var.get().strip() or None
        lbl = self.filter_lbl_var.get().strip()
        lbl_target = None if lbl == "All" else lbl
        min_m_str = self.filter_min_mood.get()
        min_m = int(min_m_str) if min_m_str.isdigit() else None

        criteria = FilterCriteria(keyword=kw, mood_label=lbl_target, min_mood_score=min_m)
        filtered = filter_entries(entries, criteria)
        self.refresh_table(filtered)

    def on_reset_filters(self) -> None:
        """Reset search and filter fields."""
        self.search_kw_var.set("")
        self.filter_lbl_var.set("All")
        self.filter_min_mood.set("Any")
        self.refresh_table()

    def on_delete_selected(self) -> None:
        """Delete selected row from persistent storage."""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Selection Required", "Please select a row in the table to delete.")
            return

        item = self.tree.item(selected[0])
        entry_id = item["values"][0]

        confirm = messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete record {entry_id}?")
        if confirm:
            success, msg = self.storage.delete_entry(str(entry_id))
            if success:
                messagebox.showinfo("Deleted", msg)
                self.refresh_table()
                self.refresh_dashboard()
                self.refresh_warnings()
                self.set_status(f"Deleted entry {entry_id}")
            else:
                messagebox.showerror("Error", msg)

    # =========================================================================
    # TAB 4: Warning Flags & Audit
    # =========================================================================
    def _build_warnings_tab(self) -> None:
        """Construct automated warning flags viewer."""
        card = tk.Frame(self.tab_warnings, bg=THEME["bg_card"], bd=1, relief="solid", padx=20, pady=16)
        card.pack(fill=tk.BOTH, expand=True, padx=16, pady=16)

        t_lbl = tk.Label(card, text="Automated Threshold Warnings & Health Anomaly Indicators", font=("Segoe UI", 12, "bold"), fg=THEME["text_dark"], bg=THEME["bg_card"])
        t_lbl.pack(anchor="w", pady=(0, 8))

        sub_lbl = tk.Label(card, text="Monitors for sudden drops, prolonged stress breaches, severe sleep debt, and burnout risks.", font=("Segoe UI", 9), fg=THEME["text_muted"], bg=THEME["bg_card"])
        sub_lbl.pack(anchor="w", pady=(0, 14))

        self.warnings_text = tk.Text(card, font=("Segoe UI", 10), bg="#F8FAFC", bd=1, relief="solid", padx=12, pady=12)
        self.warnings_text.pack(fill=tk.BOTH, expand=True)

        self.refresh_warnings()

    def refresh_warnings(self) -> None:
        """Run warning evaluation and display."""
        entries, _ = self.storage.load_entries()
        alerts = WarningEngine.evaluate_all(entries)

        self.warnings_text.delete("1.0", tk.END)
        if not alerts:
            self.warnings_text.insert(tk.END, "✅ All indicators healthy! No active warning flags or limit breaches detected.\n")
            return

        for idx, a in enumerate(alerts, start=1):
            icon = "🔴" if a.severity == "CRITICAL" else ("⚠️" if a.severity == "WARNING" else "ℹ️")
            self.warnings_text.insert(tk.END, f"{icon} [{a.severity}] #{idx} - {a.category} (Trigger Date: {a.date or 'N/A'})\n")
            self.warnings_text.insert(tk.END, f"   Details       : {a.message}\n")
            self.warnings_text.insert(tk.END, f"   Recommendation: {a.recommendation}\n\n")

    # =========================================================================
    # TAB 5: Data Management & Ingestion
    # =========================================================================
    def _build_data_mgmt_tab(self) -> None:
        """Construct bulk CSV ingestion and sample data management controls."""
        card = tk.Frame(self.tab_data_mgmt, bg=THEME["bg_card"], bd=1, relief="solid", padx=24, pady=20)
        card.pack(fill=tk.BOTH, expand=True, padx=16, pady=16)

        tk.Label(card, text="Bulk Dataset Ingestion Engine", font=("Segoe UI", 12, "bold"), fg=THEME["text_dark"], bg=THEME["bg_card"]).pack(anchor="w", pady=(0, 4))
        tk.Label(card, text="Ingest external or legacy CSV datasets with automatic schema resolution and row-by-row error logging.", font=("Segoe UI", 9), fg=THEME["text_muted"], bg=THEME["bg_card"]).pack(anchor="w", pady=(0, 14))

        ingest_frame = tk.Frame(card, bg=THEME["bg_card"])
        ingest_frame.pack(fill=tk.X, pady=(0, 20))

        choose_btn = tk.Button(
            ingest_frame,
            text="📂 Browse & Ingest Legacy CSV...",
            font=("Segoe UI", 9, "bold"),
            bg=THEME["primary"],
            fg="#FFFFFF",
            relief="flat",
            padx=14,
            pady=6,
            cursor="hand2",
            command=self.on_browse_and_ingest_csv,
        )
        choose_btn.pack(side=tk.LEFT, padx=(0, 12))

        ingest_sample_btn = tk.Button(
            ingest_frame,
            text="🧪 Ingest Sample Legacy CSV (With Error Log Demo)",
            font=("Segoe UI", 9),
            bg="#E2E8F0",
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.on_ingest_demo_legacy,
        )
        ingest_sample_btn.pack(side=tk.LEFT)

        self.ingest_log_text = tk.Text(card, height=12, font=("Consolas", 9), bg="#F8FAFC", bd=1, relief="solid", padx=10, pady=10)
        self.ingest_log_text.pack(fill=tk.BOTH, expand=True, pady=(0, 16))

        # Reset Section
        reset_frame = tk.Frame(card, bg=THEME["bg_card"])
        reset_frame.pack(fill=tk.X)

        reload_seed_btn = tk.Button(
            reset_frame,
            text="🔄 Restore Active Store to Seed Dataset (38 records)",
            font=("Segoe UI", 9),
            bg="#FEF3C7",
            fg="#92400E",
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.on_restore_seed_dataset,
        )
        reload_seed_btn.pack(side=tk.LEFT)

    def on_browse_and_ingest_csv(self) -> None:
        """Open file dialog and ingest selected CSV."""
        path = filedialog.askopenfilename(
            title="Select CSV Dataset to Ingest",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if path:
            self._execute_import(path)

    def on_ingest_demo_legacy(self) -> None:
        """Ingest the provided legacy CSV file with intentional error rows."""
        path = str(self.storage.data_dir / "legacy_import_sample.csv")
        self._execute_import(path)

    def _execute_import(self, file_path: str) -> None:
        """Run import through BulkImporter and show results."""
        try:
            summary = self.importer.import_csv_file(file_path)
            self.ingest_log_text.delete("1.0", tk.END)
            self.ingest_log_text.insert(tk.END, f"=== BULK IMPORT SUMMARY FOR {Path(file_path).name} ===\n")
            self.ingest_log_text.insert(tk.END, f"Total Rows Evaluated: {summary.total_rows}\n")
            self.ingest_log_text.insert(tk.END, f"Accepted Valid Rows : {summary.accepted_count}\n")
            self.ingest_log_text.insert(tk.END, f"Rejected Invalid Rows: {summary.rejected_count}\n")
            self.ingest_log_text.insert(tk.END, f"Detailed Audit Log  : {summary.log_file_path}\n\n")

            self.ingest_log_text.insert(tk.END, "Row Verification Details:\n")
            for rep in summary.row_reports:
                self.ingest_log_text.insert(tk.END, f"Row {rep.row_number:02d} [{rep.status}] ")
                if rep.status == "ACCEPTED" and rep.entry:
                    self.ingest_log_text.insert(tk.END, f"Date: {rep.entry.date} | Mood: {rep.entry.mood_score} | Label: {rep.entry.mood_label or 'None'}\n")
                else:
                    self.ingest_log_text.insert(tk.END, f"ERRORS: {'; '.join(rep.errors)}\n")

            if summary.accepted_count > 0:
                commit = messagebox.askyesno(
                    "Commit Valid Rows",
                    f"Successfully validated {summary.accepted_count} valid rows ({summary.rejected_count} invalid rejected).\n"
                    "Commit accepted rows into active storage?"
                )
                if commit:
                    entries, _ = self.storage.load_entries()
                    entries.extend(summary.imported_entries)
                    self.storage.save_entries(entries)
                    messagebox.showinfo("Committed", f"Merged {summary.accepted_count} records into active storage!")
                    self.refresh_dashboard()
                    self.refresh_table()
                    self.refresh_warnings()
        except Exception as e:
            messagebox.showerror("Import Error", f"Failed to ingest dataset: {e}")

    def on_restore_seed_dataset(self) -> None:
        """Reset active storage to the 38-entry seed dataset."""
        confirm = messagebox.askyesno("Restore Dataset", "Reset active storage to official seed dataset?")
        if confirm:
            sample_json = self.storage.data_dir / "sample_data.json"
            if sample_json.exists():
                import json
                with open(sample_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                entries = [MoodEntry.from_dict(item) for item in data.get("entries", [])]
                self.storage.save_entries(entries)
                messagebox.showinfo("Restored", f"Active storage restored with {len(entries)} seed entries.")
                self.refresh_dashboard()
                self.refresh_table()
                self.refresh_warnings()

    # =========================================================================
    # Header Actions
    # =========================================================================
    def on_refresh_all(self) -> None:
        """Full refresh of all views."""
        self.refresh_dashboard()
        self.refresh_table()
        self.refresh_warnings()
        self.set_status("All views refreshed.")

    def on_quick_export(self) -> None:
        """Export all summary formats immediately."""
        entries, _ = self.storage.load_entries()
        if not entries:
            messagebox.showwarning("No Data", "No records available to export.")
            return

        results = self.exporter.export_all(entries)
        messagebox.showinfo(
            "Reports Exported",
            f"Multi-Format Reports Successfully Generated!\n\n"
            f"• Markdown Report:\n  {results['markdown']}\n\n"
            f"• Standardized CSV:\n  {results['csv']}\n\n"
            f"• Plain Text Audit Log:\n  {results['text']}\n\n"
            f"• Structured JSON:\n  {results['json']}"
        )
        self.set_status("Reports exported to exports/ directory.")


def launch_gui() -> None:
    """Entry point function to start the modern GUI."""
    app = MoodJournalGUI()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
