"""
Local Data Persistence Engine for Mood Journal Analyzer.
Handles automated reading and writing to JSON and CSV files with schema validation,
corrupted file recovery, automatic template initialization, and atomic backup writes.
"""

import os
import json
import csv
import logging
from typing import List, Optional, Tuple, Dict, Any
from datetime import datetime
from pathlib import Path

from src.models import MoodEntry
from src.validator import validate_entry_dict

logger = logging.getLogger(__name__)

CSV_FIELDNAMES = [
    "id",
    "date",
    "time",
    "mood_score",
    "mood_label",
    "energy_level",
    "stress_level",
    "sleep_hours",
    "tags",
    "notes",
    "created_at",
    "updated_at",
]


class StorageManager:
    """Manages file persistence to JSON and CSV with fault tolerance and schema checking."""

    def __init__(self, data_dir: Optional[str] = None):
        if data_dir:
            self.data_dir = Path(data_dir)
        else:
            # Default to 'data' directory relative to project root
            self.data_dir = Path(__file__).resolve().parent.parent / "data"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "mood_journal.json"
        self.csv_path = self.data_dir / "mood_journal.csv"
        self.audit_log_path = self.data_dir / "audit.log"

        self.ensure_data_files()

    def log_audit(self, action: str, details: str) -> None:
        """Append an audit entry to the local audit log."""
        timestamp = datetime.now().isoformat()
        try:
            with open(self.audit_log_path, mode="a", encoding="utf-8") as f:
                f.write(f"[{timestamp}] [{action.upper()}]: {details}\n")
        except Exception as e:
            logger.warning(f"Failed to write audit log: {e}")

    def ensure_data_files(self) -> None:
        """Create clean initial templates if storage files are missing or empty."""
        # Ensure JSON file exists with valid structure
        if not self.json_path.exists() or self.json_path.stat().st_size == 0:
            initial_payload = {
                "schema_version": "1.0",
                "last_modified": datetime.now().isoformat(),
                "entries": []
            }
            try:
                with open(self.json_path, mode="w", encoding="utf-8") as f:
                    json.dump(initial_payload, f, indent=2)
                self.log_audit("INITIALIZE", f"Created fresh JSON store at {self.json_path.name}")
            except Exception as e:
                logger.error(f"Error creating initial JSON file: {e}")

        # Ensure CSV file exists with header
        if not self.csv_path.exists() or self.csv_path.stat().st_size == 0:
            try:
                with open(self.csv_path, mode="w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES)
                    writer.writeheader()
                self.log_audit("INITIALIZE", f"Created fresh CSV store at {self.csv_path.name}")
            except Exception as e:
                logger.error(f"Error creating initial CSV file: {e}")

    def load_entries(self) -> Tuple[List[MoodEntry], List[str]]:
        """
        Load all valid mood entries from storage.
        Recovers gracefully from corrupted JSON or malformed rows.
        Returns (valid_entries, corruption_warnings).
        """
        entries: List[MoodEntry] = []
        warnings: List[str] = []

        # Attempt to load from JSON first
        json_loaded = False
        if self.json_path.exists():
            try:
                with open(self.json_path, mode="r", encoding="utf-8") as f:
                    raw_content = f.read().strip()
                    if not raw_content:
                        raw_data = {"entries": []}
                    else:
                        raw_data = json.loads(raw_content)

                raw_entries = raw_data.get("entries", []) if isinstance(raw_data, dict) else raw_data
                if not isinstance(raw_entries, list):
                    warnings.append(f"JSON root structure in {self.json_path.name} was not a valid list. Auto-recovering.")
                    raw_entries = []

                for idx, item in enumerate(raw_entries, start=1):
                    if not isinstance(item, dict):
                        warnings.append(f"JSON entry #{idx} is not an object. Skipping.")
                        continue

                    is_valid, field_errs, cleaned_dict = validate_entry_dict(item)
                    if is_valid and cleaned_dict:
                        entries.append(MoodEntry.from_dict(cleaned_dict))
                    else:
                        err_str = "; ".join(f"{k}: {v}" for k, v in field_errs.items())
                        warnings.append(f"Entry #{idx} (ID: {item.get('id', 'N/A')}) invalid: {err_str}. Excluded.")

                json_loaded = True
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                warnings.append(f"Corrupted JSON detected in {self.json_path.name} ({e}). Attempting recovery from CSV backup.")
                self.backup_corrupted_file(self.json_path)
            except Exception as e:
                warnings.append(f"Unexpected error reading JSON ({e}). Attempting CSV fallback.")

        # Fallback to CSV if JSON was corrupted or missing
        if not json_loaded and self.csv_path.exists():
            csv_entries, csv_warnings = self._load_from_csv()
            entries.extend(csv_entries)
            warnings.extend(csv_warnings)
            # Re-persist clean JSON from CSV
            if entries:
                self.save_entries(entries)

        # Sort entries chronologically: date ascending, time ascending
        entries.sort(key=lambda x: (x.date, x.time))
        return entries, warnings

    def _load_from_csv(self) -> Tuple[List[MoodEntry], List[str]]:
        """Fallback loader from CSV file."""
        entries: List[MoodEntry] = []
        warnings: List[str] = []

        try:
            with open(self.csv_path, mode="r", encoding="utf-8", newline="") as f:
                reader = csv.DictReader(f)
                for line_num, row in enumerate(reader, start=2):
                    try:
                        is_valid, field_errs, cleaned = validate_entry_dict(row)
                        if is_valid and cleaned:
                            entries.append(MoodEntry.from_dict(cleaned))
                        else:
                            err_str = "; ".join(f"{k}: {v}" for k, v in field_errs.items())
                            warnings.append(f"CSV line {line_num} invalid: {err_str}. Excluded.")
                    except Exception as row_err:
                        warnings.append(f"CSV line {line_num} parse error: {row_err}.")
        except Exception as e:
            warnings.append(f"Could not read CSV fallback {self.csv_path.name}: {e}.")

        return entries, warnings

    def backup_corrupted_file(self, target_path: Path) -> None:
        """Create timestamped backup of corrupted storage file before recreating."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            backup_path = target_path.with_name(f"{target_path.stem}_corrupted_{timestamp}{target_path.suffix}")
            target_path.rename(backup_path)
            self.log_audit("RECOVERY", f"Backed up corrupted file to {backup_path.name}")
        except Exception as e:
            logger.error(f"Failed to backup corrupted file: {e}")

    def save_entries(self, entries: List[MoodEntry]) -> bool:
        """
        Atomically persist entries to both JSON and CSV files.
        Keeps both formats completely in sync.
        """
        # Sort chronologically before saving
        entries.sort(key=lambda x: (x.date, x.time))

        json_temp = self.json_path.with_suffix(".json.tmp")
        csv_temp = self.csv_path.with_suffix(".csv.tmp")

        try:
            # 1. Write JSON
            payload = {
                "schema_version": "1.0",
                "last_modified": datetime.now().isoformat(),
                "total_records": len(entries),
                "entries": [e.to_dict() for e in entries]
            }
            with open(json_temp, mode="w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)

            # 2. Write CSV
            with open(csv_temp, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES)
                writer.writeheader()
                for entry in entries:
                    writer.writerow(entry.to_csv_row())

            # Atomic rename / replace
            json_temp.replace(self.json_path)
            csv_temp.replace(self.csv_path)

            self.log_audit("SAVE", f"Successfully synced {len(entries)} records to JSON and CSV.")
            return True

        except Exception as e:
            logger.error(f"Failed to persist entries: {e}")
            self.log_audit("SAVE_ERROR", str(e))
            if json_temp.exists():
                json_temp.unlink(missing_ok=True)
            if csv_temp.exists():
                csv_temp.unlink(missing_ok=True)
            return False

    def add_entry(self, entry: MoodEntry) -> Tuple[bool, str]:
        """Add a new entry and persist."""
        entries, _ = self.load_entries()
        # Check for duplicate ID
        if any(e.id == entry.id for e in entries):
            entry.id = f"MJ-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]}"

        entries.append(entry)
        success = self.save_entries(entries)
        if success:
            self.log_audit("INSERT", f"Added entry {entry.id} ({entry.date} mood={entry.mood_score})")
            return True, f"Entry {entry.id} recorded successfully."
        return False, "Failed to write entry to storage files."

    def update_entry(self, updated: MoodEntry) -> Tuple[bool, str]:
        """Update an existing entry by ID."""
        entries, _ = self.load_entries()
        found = False
        for i, e in enumerate(entries):
            if e.id == updated.id:
                updated.updated_at = datetime.now().isoformat()
                entries[i] = updated
                found = True
                break

        if not found:
            return False, f"Entry ID '{updated.id}' not found."

        success = self.save_entries(entries)
        if success:
            self.log_audit("UPDATE", f"Updated entry {updated.id}")
            return True, f"Entry {updated.id} updated successfully."
        return False, "Failed to persist update."

    def delete_entry(self, entry_id: str) -> Tuple[bool, str]:
        """Delete an entry by ID."""
        entries, _ = self.load_entries()
        initial_len = len(entries)
        entries = [e for e in entries if e.id != entry_id]

        if len(entries) == initial_len:
            return False, f"Entry ID '{entry_id}' not found."

        success = self.save_entries(entries)
        if success:
            self.log_audit("DELETE", f"Deleted entry {entry_id}")
            return True, f"Entry {entry_id} deleted successfully."
        return False, "Failed to persist deletion."

    def get_entry_by_id(self, entry_id: str) -> Optional[MoodEntry]:
        """Retrieve a specific entry by ID."""
        entries, _ = self.load_entries()
        for e in entries:
            if e.id == entry_id:
                return e
        return None
