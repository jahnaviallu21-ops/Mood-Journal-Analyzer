"""
Interactive Terminal Interface for Mood Journal Analyzer.
Provides a menu-driven, ANSI-styled command prompt with guided workflows,
defensive input loops, formatted tabular views with pagination, and instant analytics.
"""

import os
import sys
from datetime import datetime, date
from typing import List, Optional, Tuple, Dict, Any

from src.models import MoodEntry, FilterCriteria, AggregateSummary
from src.validator import (
    validate_date,
    validate_time,
    validate_int_range,
    validate_sleep_hours,
    validate_mood_label,
    validate_tags,
    sanitize_text,
    STANDARD_MOOD_LABELS,
)
from src.storage import StorageManager
from src.analytics import (
    generate_executive_summary,
    filter_entries,
    calculate_moving_averages,
    calculate_day_of_week_analysis,
    calculate_pearson_correlation,
)
from src.warnings import WarningEngine
from src.plotter import MoodPlotter
from src.exporters import ReportExporter
from src.importer import BulkImporter

# ANSI Terminal Colors
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    UNDERLINE = "\033[4m"

    # Soft palette
    CYAN = "\033[96m"
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    MAGENTA = "\033[95m"
    WHITE = "\033[97m"

    # Backgrounds
    BG_BLUE = "\033[44m"
    BG_CYAN = "\033[46m"
    BG_DARK = "\033[40m"


def clear_screen() -> None:
    """Clear terminal screen cross-platform."""
    os.system("cls" if os.name == "nt" else "clear")


def print_banner() -> None:
    """Display branded application header."""
    print(f"{Colors.CYAN}{Colors.BOLD}")
    print(r"  __  __                 _      _                              _ ")
    print(r" |  \/  | ___   ___   __| |    | | ___  _   _ _ __ _ __   __ _| |")
    print(r" | |\/| |/ _ \ / _ \ / _` | _  | |/ _ \| | | | '__| '_ \ / _` | |")
    print(r" | |  | | (_) | (_) | (_| || |_| | (_) | |_| | |  | | | | (_| | |")
    print(r" |_|  |_|\___/ \___/ \__,_| \___/ \___/ \__,_|_|  |_| |_|\__,_|_|")
    print(f"{Colors.RESET}")
    print(f" {Colors.BOLD}Project #37: Mood Journal Analyzer{Colors.RESET} | {Colors.GREEN}Domain: Health & Wellbeing{Colors.RESET}")
    print(f" {Colors.DIM}Defensive Validation • Local File Persistence • Pattern Summaries • Visual Plots{Colors.RESET}")
    print(f"{Colors.CYAN}{'=' * 78}{Colors.RESET}\n")


class CLIApp:
    """Manages CLI navigation dispatch loop and interactive views."""

    def __init__(self, storage: Optional[StorageManager] = None):
        self.storage = storage or StorageManager()
        self.plotter = MoodPlotter()
        self.exporter = ReportExporter()
        self.importer = BulkImporter()

    def run(self) -> None:
        """Main navigation dispatch loop."""
        while True:
            try:
                self.show_main_menu()
                choice = input(f"{Colors.BOLD}{Colors.CYAN}Select an option [0-10]: {Colors.RESET}").strip()

                if choice == "1":
                    self.action_record_entry()
                elif choice == "2":
                    self.action_query_entries()
                elif choice == "3":
                    self.action_executive_summary()
                elif choice == "4":
                    self.action_warning_alerts()
                elif choice == "5":
                    self.action_visual_plots()
                elif choice == "6":
                    self.action_export_reports()
                elif choice == "7":
                    self.action_bulk_import()
                elif choice == "8":
                    self.action_manage_entry()
                elif choice == "9":
                    self.action_launch_gui()
                elif choice == "10":
                    self.action_reload_sample_data()
                elif choice == "0":
                    print(f"\n{Colors.GREEN}Thank you for taking care of your wellbeing. Goodbye! 🌿{Colors.RESET}\n")
                    break
                else:
                    print(f"{Colors.RED}Invalid selection. Please choose an option from 0 to 10.{Colors.RESET}")
                    input(f"{Colors.DIM}Press Enter to continue...{Colors.RESET}")
            except (KeyboardInterrupt, EOFError):
                print(f"\n\n{Colors.YELLOW}Operation cancelled by user. Returning to menu...{Colors.RESET}")
            except Exception as e:
                print(f"\n{Colors.RED}Unexpected error: {e}{Colors.RESET}")
                input(f"{Colors.DIM}Press Enter to continue...{Colors.RESET}")

    def show_main_menu(self) -> None:
        """Render the primary navigation menu."""
        clear_screen()
        print_banner()

        entries, warnings = self.storage.load_entries()
        total_count = len(entries)
        latest_date = entries[-1].date if entries else "None"

        # Mini status strip
        print(f" {Colors.BOLD}System Status:{Colors.RESET} {Colors.GREEN}{total_count} records loaded{Colors.RESET} | Latest Entry: {Colors.CYAN}{latest_date}{Colors.RESET}")
        if warnings:
            print(f" {Colors.YELLOW}⚠️  Notice: {len(warnings)} storage notices logged during startup.{Colors.RESET}")
        print(f"{Colors.DIM}{'-' * 78}{Colors.RESET}")

        print(f" {Colors.BOLD}MAIN NAVIGATION MENU:{Colors.RESET}")
        print(f"   {Colors.CYAN}[1]{Colors.RESET}  📝 Record New Mood Journal Entry")
        print(f"   {Colors.CYAN}[2]{Colors.RESET}  🔍 View, Query & Search Journal Entries")
        print(f"   {Colors.CYAN}[3]{Colors.RESET}  📊 Executive Wellness Summary & Trend Analytics")
        print(f"   {Colors.CYAN}[4]{Colors.RESET}  ⚠️  Threshold Warning Indicators & Anomaly Alerts")
        print(f"   {Colors.CYAN}[5]{Colors.RESET}  📈 Visual Data Plotting (Matplotlib & ASCII Graphs)")
        print(f"   {Colors.CYAN}[6]{Colors.RESET}  📤 Export Multi-Format Reports (Markdown/CSV/TXT/JSON)")
        print(f"   {Colors.CYAN}[7]{Colors.RESET}  📥 Bulk Ingest External / Legacy CSV Dataset")
        print(f"   {Colors.CYAN}[8]{Colors.RESET}  ✏️  Edit or Delete Existing Record")
        print(f"   {Colors.CYAN}[9]{Colors.RESET}  🖥️  Launch Graphical Interface (Tkinter GUI)")
        print(f"   {Colors.CYAN}[10]{Colors.RESET} 🔄 Reset / Reload Official Sample Dataset")
        print(f"   {Colors.CYAN}[0]{Colors.RESET}  🚪 Exit Application")
        print(f"{Colors.DIM}{'-' * 78}{Colors.RESET}")

    # =========================================================================
    # Defensive Input Wrapper Routines
    # =========================================================================
    def prompt_date_defensive(self, prompt_text: str, default: Optional[str] = None) -> str:
        """Loop until a valid YYYY-MM-DD date is provided."""
        while True:
            default_str = f" [default: {default}]" if default else ""
            raw = input(f"{prompt_text}{default_str}: ").strip()
            if not raw and default:
                return default

            valid, err, clean_val = validate_date(raw)
            if valid and clean_val:
                return clean_val
            print(f"  {Colors.RED}❌ Error: {err}{Colors.RESET}")

    def prompt_time_defensive(self, prompt_text: str, default: Optional[str] = None) -> str:
        """Loop until a valid HH:MM 24-hr time is provided."""
        while True:
            default_str = f" [default: {default}]" if default else ""
            raw = input(f"{prompt_text}{default_str}: ").strip()
            if not raw and default:
                return default

            valid, err, clean_val = validate_time(raw)
            if valid and clean_val:
                return clean_val
            print(f"  {Colors.RED}❌ Error: {err}{Colors.RESET}")

    def prompt_int_defensive(self, prompt_text: str, min_val: int, max_val: int, default: Optional[int] = None) -> int:
        """Loop until valid integer within bounds is provided."""
        while True:
            default_str = f" [default: {default}]" if default is not None else ""
            raw = input(f"{prompt_text}{default_str}: ").strip()
            if not raw and default is not None:
                return default

            valid, err, clean_val = validate_int_range(raw, min_val, max_val, prompt_text)
            if valid and clean_val is not None:
                return clean_val
            print(f"  {Colors.RED}❌ Error: {err}{Colors.RESET}")

    def prompt_float_defensive(self, prompt_text: str, min_val: float, max_val: float, default: Optional[float] = None) -> float:
        """Loop until valid float within bounds is provided."""
        while True:
            default_str = f" [default: {default}]" if default is not None else ""
            raw = input(f"{prompt_text}{default_str}: ").strip()
            if not raw and default is not None:
                return default

            valid, err, clean_val = validate_sleep_hours(raw)
            if valid and clean_val is not None:
                return clean_val
            print(f"  {Colors.RED}❌ Error: {err}{Colors.RESET}")

    def prompt_optional_mood_label(self) -> Optional[str]:
        """Prompt user for optional mood label with quick suggestion list."""
        print(f"\n  {Colors.BOLD}Optional Mood Label{Colors.RESET} (Press Enter to leave blank, or choose/type):")
        labels_sample = ", ".join(STANDARD_MOOD_LABELS[:8])
        print(f"  {Colors.DIM}Suggestions: {labels_sample}, etc.{Colors.RESET}")
        while True:
            raw = input("  Enter mood label (optional): ").strip()
            if not raw:
                return None
            valid, err, clean_val = validate_mood_label(raw)
            if valid:
                return clean_val
            print(f"  {Colors.RED}❌ Error: {err}{Colors.RESET}")

    def prompt_tags_defensive(self) -> List[str]:
        """Prompt for optional activity tags."""
        raw = input("  Tags (comma-separated, e.g. work, exercise, study) [optional]: ").strip()
        _, _, tags = validate_tags(raw)
        return tags

    # =========================================================================
    # Action 1: Record New Entry
    # =========================================================================
    def action_record_entry(self) -> None:
        """Guided workflow to record a new journal entry with defensive validation."""
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.GREEN}📝 RECORD NEW MOOD JOURNAL ENTRY{Colors.RESET}")
        print(f"{Colors.DIM}All entries are verified in real time against domain boundary constraints.{Colors.RESET}\n")

        today_str = date.today().strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%H:%M")

        entry_date = self.prompt_date_defensive("  Entry Date (YYYY-MM-DD)", default=today_str)
        entry_time = self.prompt_time_defensive("  Entry Time (HH:MM 24-hr)", default=now_str)

        print(f"\n  {Colors.BOLD}Rating Scales (1 to 10):{Colors.RESET}")
        print(f"  {Colors.DIM}Mood: 1 (Extremely Low) to 10 (Peak Joy/Euphoric){Colors.RESET}")
        mood_score = self.prompt_int_defensive("  Mood Score (1-10)", 1, 10, default=7)

        mood_label = self.prompt_optional_mood_label()

        print(f"\n  {Colors.DIM}Energy: 1 (Exhausted/Drained) to 10 (Fully Energized){Colors.RESET}")
        energy = self.prompt_int_defensive("  Energy Level (1-10)", 1, 10, default=6)

        print(f"\n  {Colors.DIM}Stress: 1 (Completely Relaxed) to 10 (Extreme Tension/Panic){Colors.RESET}")
        stress = self.prompt_int_defensive("  Stress Level (1-10)", 1, 10, default=4)

        sleep = self.prompt_float_defensive("  Sleep Hours preceding this entry (0.0 - 24.0)", 0.0, 24.0, default=7.5)

        tags = self.prompt_tags_defensive()

        notes_raw = input("\n  Journal Reflection / Notes (optional, press Enter when done):\n  > ")
        notes = sanitize_text(notes_raw, max_len=1500)

        entry_id = f"MJ-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]}"

        new_entry = MoodEntry(
            id=entry_id,
            date=entry_date,
            time=entry_time,
            mood_score=mood_score,
            mood_label=mood_label,
            energy_level=energy,
            stress_level=stress,
            sleep_hours=sleep,
            tags=tags,
            notes=notes,
        )

        success, msg = self.storage.add_entry(new_entry)
        if success:
            print(f"\n{Colors.GREEN}✅ Success: {msg}{Colors.RESET}")
            # Instant threshold check
            alerts = WarningEngine.evaluate_all([new_entry])
            criticals = [a for a in alerts if a.severity == "CRITICAL"]
            if criticals:
                print(f"{Colors.RED}⚠️  Alert: {criticals[0].message}{Colors.RESET}")
        else:
            print(f"\n{Colors.RED}❌ Error saving entry: {msg}{Colors.RESET}")

        input(f"\n{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 2: View & Query Entries
    # =========================================================================
    def action_query_entries(self) -> None:
        """Search and filter records with paginated table output."""
        entries, _ = self.storage.load_entries()
        if not entries:
            print(f"\n{Colors.YELLOW}No journal records found in storage.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}🔍 SEARCH & FILTER JOURNAL RECORDS{Colors.RESET}")
        print(f"{Colors.DIM}Filter by keyword, mood label, rating score, or date range.{Colors.RESET}\n")

        print("  Filter Options (press Enter to skip any criteria):")
        kw = input("  Search Keyword (matches notes, tags, or label): ").strip() or None
        lbl = input("  Mood Label filter (e.g. Joyful, Calm, or 'Unlabeled'): ").strip() or None

        min_m_raw = input("  Minimum Mood Score (1-10): ").strip()
        min_m = int(min_m_raw) if min_m_raw.isdigit() else None

        max_m_raw = input("  Maximum Mood Score (1-10): ").strip()
        max_m = int(max_m_raw) if max_m_raw.isdigit() else None

        start_d = input("  Start Date (YYYY-MM-DD): ").strip() or None
        end_d = input("  End Date (YYYY-MM-DD): ").strip() or None

        criteria = FilterCriteria(
            keyword=kw,
            mood_label=lbl,
            min_mood_score=min_m,
            max_mood_score=max_m,
            start_date=start_d,
            end_date=end_d,
        )

        filtered = filter_entries(entries, criteria)
        self._display_paginated_table(filtered)

    def _display_paginated_table(self, records: List[MoodEntry], page_size: int = 10) -> None:
        """Display records in a formatted fixed-width table with pagination."""
        if not records:
            print(f"\n{Colors.YELLOW}No matching records found for the given criteria.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        total_pages = (len(records) + page_size - 1) // page_size
        current_page = 0

        while True:
            clear_screen()
            print_banner()
            start_idx = current_page * page_size
            end_idx = min(start_idx + page_size, len(records))
            page_slice = records[start_idx:end_idx]

            print(f" {Colors.BOLD}Query Results:{Colors.RESET} {len(records)} total match(es) | {Colors.CYAN}Page {current_page + 1} of {total_pages}{Colors.RESET}")
            print(f"{Colors.CYAN}{'=' * 78}{Colors.RESET}")
            print(f"{'#':<3} {'DATE':<11} {'TIME':<6} {'MOOD':<5} {'LABEL':<13} {'ENR':<4} {'STR':<4} {'SLEEP':<6} {'NOTES':<20}")
            print(f"{Colors.DIM}{'-' * 78}{Colors.RESET}")

            for idx, e in enumerate(page_slice, start=start_idx + 1):
                lbl = (e.mood_label or "-")[:12]
                note = e.notes.replace("\n", " ")[:18]
                if len(e.notes) > 18:
                    note += ".."

                mood_color = Colors.GREEN if e.mood_score >= 7 else (Colors.YELLOW if e.mood_score >= 5 else Colors.RED)
                print(f"{idx:<3} {e.date:<11} {e.time:<6} {mood_color}{e.mood_score:<5}{Colors.RESET} {lbl:<13} {e.energy_level:<4} {e.stress_level:<4} {e.sleep_hours:<6.1f} {note:<20}")

            print(f"{Colors.CYAN}{'=' * 78}{Colors.RESET}")
            print(f" Navigation: [{Colors.BOLD}N{Colors.RESET}]ext Page | [{Colors.BOLD}P{Colors.RESET}]revious Page | [{Colors.BOLD}V{Colors.RESET}]iew Details by # | [{Colors.BOLD}Q{Colors.RESET}]uit to Menu")

            cmd = input(f"{Colors.BOLD}Choice: {Colors.RESET}").strip().lower()
            if cmd == "n":
                if current_page < total_pages - 1:
                    current_page += 1
                else:
                    print(f"{Colors.YELLOW}Already at the last page.{Colors.RESET}")
            elif cmd == "p":
                if current_page > 0:
                    current_page -= 1
                else:
                    print(f"{Colors.YELLOW}Already at the first page.{Colors.RESET}")
            elif cmd == "v":
                rec_num = input("Enter entry number to inspect: ").strip()
                if rec_num.isdigit():
                    num = int(rec_num)
                    if 1 <= num <= len(records):
                        self._show_entry_details(records[num - 1])
                    else:
                        print(f"{Colors.RED}Out of range.{Colors.RESET}")
                        input(f"{Colors.DIM}Press Enter...{Colors.RESET}")
            elif cmd in ("q", "quit", "exit", ""):
                break

    def _show_entry_details(self, entry: MoodEntry) -> None:
        """Display full detail inspection card for a single entry."""
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}📋 ENTRY DETAILS: {entry.id}{Colors.RESET}\n")
        print(f"  • Date & Time    : {entry.date} at {entry.time}")
        print(f"  • Mood Score     : {Colors.BOLD}{entry.mood_score} / 10{Colors.RESET}")
        print(f"  • Mood Label     : {entry.mood_label or 'None (Unlabeled)'}")
        print(f"  • Energy Level   : {entry.energy_level} / 10")
        print(f"  • Stress Level   : {entry.stress_level} / 10")
        print(f"  • Sleep Duration : {entry.sleep_hours:.1f} hours")
        print(f"  • Context Tags   : {', '.join(entry.tags) if entry.tags else 'None'}")
        print(f"  • Created At     : {entry.created_at}")
        print(f"  • Last Updated   : {entry.updated_at}")
        print(f"\n  {Colors.BOLD}Journal Reflection / Notes:{Colors.RESET}")
        print(f"  {entry.notes if entry.notes else '[No notes recorded]'}")
        print(f"\n{Colors.CYAN}{'=' * 78}{Colors.RESET}")
        input(f"{Colors.DIM}Press Enter to return to table...{Colors.RESET}")

    # =========================================================================
    # Action 3: Executive Summary
    # =========================================================================
    def action_executive_summary(self) -> None:
        """Display aggregated metrics, volatility index, and day-of-week trends."""
        entries, _ = self.storage.load_entries()
        if not entries:
            print(f"\n{Colors.YELLOW}No entries recorded yet to generate executive summary.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        clear_screen()
        print_banner()
        summary = generate_executive_summary(entries)

        print(f"{Colors.BOLD}{Colors.CYAN}📊 EXECUTIVE WELLNESS SUMMARY & TREND ANALYTICS{Colors.RESET}")
        print(f"{Colors.DIM}Dataset Period: {summary.date_range_str} ({summary.total_entries} records across {summary.days_logged} logged days){Colors.RESET}\n")

        # Status badge
        badge_color = getattr(Colors, summary.wellness_indicator_color, Colors.WHITE)
        print(f"  {Colors.BOLD}Overall Wellness Status:{Colors.RESET} {badge_color}{Colors.BOLD}[ {summary.wellness_status} ]{Colors.RESET}")
        print(f"  {Colors.BOLD}Mood Trend Trajectory  :{Colors.RESET} {Colors.CYAN}{summary.mood_trend}{Colors.RESET}\n")

        print(f"  {Colors.BOLD}CORE AGGREGATION METRICS:{Colors.RESET}")
        print(f"  {'-' * 55}")
        print(f"  • Average Mood Score   : {Colors.BOLD}{summary.avg_mood:.2f} / 10{Colors.RESET} (Min: {summary.min_mood}, Max: {summary.max_mood})")
        print(f"  • Mood Volatility (σ)  : {summary.mood_volatility:.2f} {Colors.DIM}(<1.5 = Stable, >2.5 = High Fluctuations){Colors.RESET}")
        print(f"  • Average Energy Level : {summary.avg_energy:.2f} / 10")
        print(f"  • Average Stress Level : {summary.avg_stress:.2f} / 10")
        print(f"  • Average Sleep Hours  : {summary.avg_sleep:.1f} hrs/night")
        print(f"  • Current Streak       : {Colors.GREEN}{summary.current_streak_days} days{Colors.RESET}")
        print(f"  • Longest Streak       : {summary.longest_streak_days} days")
        print(f"  • Best Day of Week     : {Colors.GREEN}{summary.best_day_of_week}{Colors.RESET}")
        print(f"  • Challenging Day      : {Colors.YELLOW}{summary.worst_day_of_week}{Colors.RESET}")
        print(f"  {'-' * 55}\n")

        print(f"  {Colors.BOLD}FREQUENT MOOD LABELS:{Colors.RESET}")
        for lbl, count in list(summary.mood_label_counts.items())[:6]:
            pct = (count / summary.total_entries) * 100
            bar = "█" * int(pct // 5)
            print(f"  • {lbl:<15}: {count:>2} ({pct:>5.1f}%) {Colors.CYAN}{bar}{Colors.RESET}")

        # Day of week breakdown
        dow = calculate_day_of_week_analysis(entries)
        print(f"\n  {Colors.BOLD}DAY OF WEEK PATTERNS:{Colors.RESET}")
        print(f"  {'DAY':<10} {'ENTRIES':<8} {'AVG MOOD':<10} {'AVG STRESS':<10} {'AVG ENERGY':<10}")
        print(f"  {'-' * 50}")
        for day, d in dow.items():
            if d["count"] > 0:
                print(f"  {day:<10} {d['count']:<8} {d['avg_mood']:<10.1f} {d['avg_stress']:<10.1f} {d['avg_energy']:<10.1f}")
            else:
                print(f"  {day:<10} {'0':<8} {'-':<10} {'-':<10} {'-':<10}")

        print(f"\n{Colors.CYAN}{'=' * 78}{Colors.RESET}")
        input(f"{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 4: Warning Alerts
    # =========================================================================
    def action_warning_alerts(self) -> None:
        """Inspect threshold warning flags and clinical/wellbeing recommendations."""
        entries, _ = self.storage.load_entries()
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.YELLOW}⚠️  THRESHOLD WARNING INDICATORS & ANOMALY AUDIT{Colors.RESET}")
        print(f"{Colors.DIM}Automated checks for burnout risk, steep mood drops, high stress, and tracking gaps.{Colors.RESET}\n")

        alerts = WarningEngine.evaluate_all(entries)
        if not alerts:
            print(f"  {Colors.GREEN}✅ All indicators within healthy thresholds. No active warnings detected.{Colors.RESET}")
        else:
            for idx, a in enumerate(alerts, start=1):
                color = Colors.RED if a.severity == "CRITICAL" else (Colors.YELLOW if a.severity == "WARNING" else Colors.CYAN)
                icon = "🔴" if a.severity == "CRITICAL" else ("⚠️" if a.severity == "WARNING" else "ℹ️")
                print(f"  {icon} {color}{Colors.BOLD}[{a.severity}] #{idx} - {a.category}{Colors.RESET}")
                print(f"     Details       : {a.message}")
                if a.date:
                    print(f"     Trigger Date  : {a.date}")
                print(f"     Recommendation: {Colors.BOLD}{a.recommendation}{Colors.RESET}\n")

        print(f"{Colors.CYAN}{'=' * 78}{Colors.RESET}")
        input(f"{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 5: Visual Data Plotting
    # =========================================================================
    def action_visual_plots(self) -> None:
        """Generate Matplotlib charts and display in-terminal ASCII trend chart."""
        entries, _ = self.storage.load_entries()
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}📈 VISUAL DATA PLOTTING & TREND GRAPHS{Colors.RESET}\n")

        if not entries:
            print(f"{Colors.YELLOW}No entries to plot.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        # Render ASCII Chart first
        print(f"{Colors.BOLD}In-Terminal Mood Trajectory Chart:{Colors.RESET}")
        ascii_chart = self.plotter.render_terminal_ascii_chart(entries, width=45, height=9)
        print(f"{Colors.CYAN}{ascii_chart}{Colors.RESET}\n")

        # Generate Matplotlib plots
        if self.plotter.is_available:
            print(f"{Colors.BOLD}Generating publication-quality Matplotlib figures...{Colors.RESET}")
            results = self.plotter.generate_all_plots(entries, base_name="mood_report")
            print(f"{Colors.GREEN}✅ High-resolution charts saved to exports directory:{Colors.RESET}")
            for name, path in results.items():
                print(f"   • {name.title():<18}: {path}")
        else:
            print(f"{Colors.YELLOW}Matplotlib not available. Terminal ASCII rendering used as defensive fallback.{Colors.RESET}")

        print(f"\n{Colors.CYAN}{'=' * 78}{Colors.RESET}")
        input(f"{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 6: Export Multi-Format Reports
    # =========================================================================
    def action_export_reports(self) -> None:
        """Export Markdown, CSV, plain-text audit log, and JSON files."""
        entries, _ = self.storage.load_entries()
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}📤 EXPORT MULTI-FORMAT WELLNESS REPORTS{Colors.RESET}\n")

        if not entries:
            print(f"{Colors.YELLOW}No entries to export.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        results = self.exporter.export_all(entries)
        print(f"{Colors.GREEN}✅ Reports generated successfully:{Colors.RESET}\n")
        print(f"  • Structured Markdown Report : {results['markdown']}")
        print(f"  • Standardized CSV Report    : {results['csv']}")
        print(f"  • Plain-Text Audit Log       : {results['text']}")
        print(f"  • Machine-Readable JSON      : {results['json']}")

        print(f"\n{Colors.CYAN}{'=' * 78}{Colors.RESET}")
        input(f"{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 7: Bulk Ingest CSV
    # =========================================================================
    def action_bulk_import(self) -> None:
        """Ingest legacy CSV dataset with row-by-row validation and audit log."""
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}📥 BULK DATASET INGESTION & FORMAT VALIDATION{Colors.RESET}")
        print(f"{Colors.DIM}Ingests external or legacy CSV files with flexible column mappings and row-by-row error logs.{Colors.RESET}\n")

        default_legacy = str(self.storage.data_dir / "legacy_import_sample.csv")
        file_path = input(f"  Enter CSV path to import [default: {default_legacy}]: ").strip()
        if not file_path:
            file_path = default_legacy

        if not os.path.exists(file_path):
            print(f"{Colors.RED}File not found: {file_path}{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        try:
            summary = self.importer.import_csv_file(file_path)
            print(f"\n{Colors.BOLD}Import Results:{Colors.RESET}")
            print(f"  • Total Rows Evaluated : {summary.total_rows}")
            print(f"  • Accepted Valid Rows  : {Colors.GREEN}{summary.accepted_count}{Colors.RESET}")
            print(f"  • Rejected Invalid Rows: {Colors.RED}{summary.rejected_count}{Colors.RESET}")
            print(f"  • Audit Log Generated  : {summary.log_file_path}")

            if summary.accepted_count > 0:
                commit = input(f"\nCommit {summary.accepted_count} valid records into active storage? [y/N]: ").strip().lower()
                if commit in ("y", "yes"):
                    entries, _ = self.storage.load_entries()
                    entries.extend(summary.imported_entries)
                    self.storage.save_entries(entries)
                    print(f"{Colors.GREEN}✅ Successfully merged {summary.accepted_count} records into active storage!{Colors.RESET}")
                else:
                    print(f"{Colors.YELLOW}Import cancelled. No records committed.{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.RED}Import failed: {e}{Colors.RESET}")

        input(f"\n{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 8: Edit or Delete
    # =========================================================================
    def action_manage_entry(self) -> None:
        """Edit or delete an existing journal entry."""
        entries, _ = self.storage.load_entries()
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.CYAN}✏️  EDIT OR DELETE JOURNAL ENTRY{Colors.RESET}\n")

        entry_id = input("  Enter Entry ID (e.g. MJ-2026-001): ").strip()
        target = self.storage.get_entry_by_id(entry_id)

        if not target:
            print(f"{Colors.RED}Entry with ID '{entry_id}' was not found.{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to return...{Colors.RESET}")
            return

        print(f"\n  Found: {target.id} | Date: {target.date} | Mood: {target.mood_score} | Label: {target.mood_label or 'None'}")
        action = input("  Choose action - [E]dit / [D]elete / [C]ancel: ").strip().lower()

        if action == "d":
            confirm = input(f"  Are you sure you want to delete {target.id}? [y/N]: ").strip().lower()
            if confirm in ("y", "yes"):
                success, msg = self.storage.delete_entry(target.id)
                if success:
                    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")
                else:
                    print(f"{Colors.RED}❌ {msg}{Colors.RESET}")
        elif action == "e":
            print(f"\n  {Colors.DIM}Press Enter to keep existing value.{Colors.RESET}")
            new_date = self.prompt_date_defensive("  New Date", default=target.date)
            new_time = self.prompt_time_defensive("  New Time", default=target.time)
            new_mood = self.prompt_int_defensive("  New Mood Score (1-10)", 1, 10, default=target.mood_score)
            new_label = self.prompt_optional_mood_label() or target.mood_label
            new_energy = self.prompt_int_defensive("  New Energy (1-10)", 1, 10, default=target.energy_level)
            new_stress = self.prompt_int_defensive("  New Stress (1-10)", 1, 10, default=target.stress_level)
            new_sleep = self.prompt_float_defensive("  New Sleep (0-24 hrs)", 0.0, 24.0, default=target.sleep_hours)
            new_notes = input(f"  New Notes [current: {target.notes}]: ").strip() or target.notes

            updated_entry = MoodEntry(
                id=target.id,
                date=new_date,
                time=new_time,
                mood_score=new_mood,
                mood_label=new_label,
                energy_level=new_energy,
                stress_level=new_stress,
                sleep_hours=new_sleep,
                tags=target.tags,
                notes=sanitize_text(new_notes),
                created_at=target.created_at,
            )

            success, msg = self.storage.update_entry(updated_entry)
            if success:
                print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")
            else:
                print(f"{Colors.RED}❌ {msg}{Colors.RESET}")

        input(f"\n{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")

    # =========================================================================
    # Action 9: Launch Graphical Interface
    # =========================================================================
    def action_launch_gui(self) -> None:
        """Launch modern Tkinter Graphical User Interface."""
        print(f"\n{Colors.CYAN}Launching Tkinter Graphical Interface...{Colors.RESET}")
        try:
            from src.gui import launch_gui
            launch_gui()
        except Exception as e:
            print(f"{Colors.RED}Could not start GUI: {e}{Colors.RESET}")
            input(f"{Colors.DIM}Press Enter to continue...{Colors.RESET}")

    # =========================================================================
    # Action 10: Reload Sample Dataset
    # =========================================================================
    def action_reload_sample_data(self) -> None:
        """Reset active storage to the curated 38-entry sample dataset."""
        clear_screen()
        print_banner()
        print(f"{Colors.BOLD}{Colors.YELLOW}🔄 RELOAD OFFICIAL SAMPLE DATASET{Colors.RESET}\n")

        confirm = input("This will restore active storage to the official seed dataset (38 realistic entries). Proceed? [y/N]: ").strip().lower()
        if confirm in ("y", "yes"):
            sample_json = self.storage.data_dir / "sample_data.json"
            if sample_json.exists():
                import json
                with open(sample_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                entries = [MoodEntry.from_dict(item) for item in data.get("entries", [])]
                self.storage.save_entries(entries)
                print(f"{Colors.GREEN}✅ Active records successfully reloaded from sample dataset ({len(entries)} entries).{Colors.RESET}")
            else:
                print(f"{Colors.RED}Sample dataset file not found at {sample_json}.{Colors.RESET}")

        input(f"\n{Colors.DIM}Press Enter to return to main menu...{Colors.RESET}")
