"""
Multi-Format Summary Export Engine for Mood Journal Analyzer.
Generates structured Markdown reports, plain-text audit logs,
standardized CSV exports, and machine-readable JSON summaries for external review.
"""

import csv
import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any

from src.models import MoodEntry, AggregateSummary, WarningAlert
from src.analytics import generate_executive_summary, calculate_day_of_week_analysis
from src.warnings import WarningEngine
from src.storage import CSV_FIELDNAMES


class ReportExporter:
    """Manages multi-format report generation and file persistence."""

    def __init__(self, exports_dir: Optional[Path] = None):
        if exports_dir:
            self.exports_dir = exports_dir
        else:
            self.exports_dir = Path(__file__).resolve().parent.parent / "exports"
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def export_all(
        self,
        entries: List[MoodEntry],
        summary: Optional[AggregateSummary] = None,
        alerts: Optional[List[WarningAlert]] = None,
        base_name: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate and save reports in all supported formats (Markdown, CSV, TXT, JSON).
        Returns mapping of format to generated file path.
        """
        if summary is None:
            summary = generate_executive_summary(entries)
        if alerts is None:
            alerts = WarningEngine.evaluate_all(entries)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        prefix = base_name or f"mood_report_{ts}"

        md_path = self.export_markdown(entries, summary, alerts, f"{prefix}.md")
        csv_path = self.export_csv(entries, f"{prefix}.csv")
        txt_path = self.export_plain_text(entries, summary, alerts, f"{prefix}_audit.txt")
        json_path = self.export_json(entries, summary, alerts, f"{prefix}.json")

        return {
            "markdown": str(md_path),
            "csv": str(csv_path),
            "text": str(txt_path),
            "json": str(json_path),
        }

    def export_markdown(
        self,
        entries: List[MoodEntry],
        summary: AggregateSummary,
        alerts: List[WarningAlert],
        filename: str
    ) -> Path:
        """Generate structured Markdown executive wellness report."""
        out_path = self.exports_dir / filename
        dow = calculate_day_of_week_analysis(entries)

        with open(out_path, mode="w", encoding="utf-8") as f:
            f.write("# 🌿 Mood Journal Analyzer - Executive Wellness Report\n\n")
            f.write(f"**Generated On:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n")
            f.write(f"**Dataset Period:** {summary.date_range_str}  \n")
            f.write(f"**Total Entries Analyzed:** {summary.total_entries}  \n")
            f.write(f"**Unique Days Logged:** {summary.days_logged}  \n\n")

            f.write("## 1. Executive Status & Key Metrics\n\n")
            f.write(f"> **Overall Wellness Status:** `{summary.wellness_status}`  \n")
            f.write(f"> **Overall Trajectory / Trend:** `{summary.mood_trend}`  \n\n")

            f.write("| Metric | Value | Domain Benchmark / Scale |\n")
            f.write("| :--- | :---: | :--- |\n")
            f.write(f"| **Average Mood Score** | **{summary.avg_mood:.2f} / 10** | (1: Extremely Low – 10: Peak/Joyful) |\n")
            f.write(f"| **Mood Score Range** | **{summary.min_mood} - {summary.max_mood}** | Minimum to Maximum recorded |\n")
            f.write(f"| **Mood Volatility Index (σ)** | **{summary.mood_volatility:.2f}** | (<1.5: Stable, >2.5: High Fluctuations) |\n")
            f.write(f"| **Average Energy Level** | **{summary.avg_energy:.2f} / 10** | (1: Drained – 10: Highly Energized) |\n")
            f.write(f"| **Average Stress Level** | **{summary.avg_stress:.2f} / 10** | (1: Relaxed – 10: Extreme Distress) |\n")
            f.write(f"| **Average Sleep Hours** | **{summary.avg_sleep:.1f} hrs** | Recommended: 7.0 - 9.0 hrs |\n")
            f.write(f"| **Current Streak** | **{summary.current_streak_days} days** | Consecutive days tracked |\n")
            f.write(f"| **Longest Streak** | **{summary.longest_streak_days} days** | Historical continuous record |\n")
            f.write(f"| **Best Day of Week** | **{summary.best_day_of_week}** | Highest average mood |\n")
            f.write(f"| **Challenging Day** | **{summary.worst_day_of_week}** | Lowest average mood |\n\n")

            f.write("## 2. Mood Label Distribution\n\n")
            if summary.mood_label_counts:
                f.write("| Mood Label | Occurrences | Percentage |\n")
                f.write("| :--- | :---: | :---: |\n")
                for lbl, count in summary.mood_label_counts.items():
                    pct = (count / max(1, summary.total_entries)) * 100
                    f.write(f"| `{lbl}` | {count} | {pct:.1f}% |\n")
            else:
                f.write("*No mood labels recorded in this dataset.*  \n")
            f.write("\n")

            f.write("## 3. Day of Week Patterns\n\n")
            f.write("| Day | Entries | Avg Mood | Avg Stress | Avg Energy |\n")
            f.write("| :--- | :---: | :---: | :---: | :---: |\n")
            for day, d_data in dow.items():
                if d_data["count"] > 0:
                    f.write(f"| {day} | {d_data['count']} | {d_data['avg_mood']:.1f}/10 | {d_data['avg_stress']:.1f}/10 | {d_data['avg_energy']:.1f}/10 |\n")
                else:
                    f.write(f"| {day} | 0 | - | - | - |\n")
            f.write("\n")

            f.write("## 4. Threshold Warnings & Anomaly Indicators\n\n")
            if alerts:
                for a in alerts:
                    icon = "🔴" if a.severity == "CRITICAL" else ("⚠️" if a.severity == "WARNING" else "ℹ️")
                    f.write(f"### {icon} [{a.severity}] {a.category}\n")
                    f.write(f"- **Details:** {a.message}\n")
                    if a.date:
                        f.write(f"- **Date Flagged:** `{a.date}`\n")
                    f.write(f"- **Recommendation:** {a.recommendation}\n\n")
            else:
                f.write("✅ *No active warning thresholds or safety flags detected. Patterns are within healthy parameters.*\n\n")

            f.write("## 5. Recent Journal Logs\n\n")
            f.write("| Date | Time | Mood | Label | Energy | Stress | Sleep | Tags | Notes |\n")
            f.write("| :---: | :---: | :---: | :--- | :---: | :---: | :---: | :--- | :--- |\n")
            for e in entries[-15:]:
                tags_str = ", ".join(e.tags) if e.tags else "-"
                notes_clean = e.notes.replace("\n", " ")[:60]
                if len(e.notes) > 60:
                    notes_clean += "..."
                f.write(f"| {e.date} | {e.time} | {e.mood_score}/10 | {e.mood_label or '-'} | {e.energy_level}/10 | {e.stress_level}/10 | {e.sleep_hours:.1f}h | {tags_str} | {notes_clean} |\n")
            f.write("\n---\n*Report generated by Mood Journal Analyzer.*  \n")

        return out_path

    def export_csv(self, entries: List[MoodEntry], filename: str) -> Path:
        """Export standardized CSV format."""
        out_path = self.exports_dir / filename
        with open(out_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES)
            writer.writeheader()
            for e in entries:
                writer.writerow(e.to_csv_row())
        return out_path

    def export_plain_text(
        self,
        entries: List[MoodEntry],
        summary: AggregateSummary,
        alerts: List[WarningAlert],
        filename: str
    ) -> Path:
        """Export plain-text audit log and review document."""
        out_path = self.exports_dir / filename
        with open(out_path, mode="w", encoding="utf-8") as f:
            f.write("=" * 72 + "\n")
            f.write("MOOD JOURNAL ANALYZER - PLAIN TEXT AUDIT REPORT\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Period   : {summary.date_range_str}\n")
            f.write(f"Records  : {summary.total_entries}\n")
            f.write("=" * 72 + "\n\n")

            f.write("EXECUTIVE SUMMARY METRICS:\n")
            f.write("-" * 40 + "\n")
            f.write(f"Wellness Status       : {summary.wellness_status}\n")
            f.write(f"Mood Trend Trajectory : {summary.mood_trend}\n")
            f.write(f"Average Mood Score    : {summary.avg_mood:.2f} / 10\n")
            f.write(f"Mood Volatility (σ)   : {summary.mood_volatility:.2f}\n")
            f.write(f"Average Energy Level  : {summary.avg_energy:.2f} / 10\n")
            f.write(f"Average Stress Level  : {summary.avg_stress:.2f} / 10\n")
            f.write(f"Average Sleep Hours   : {summary.avg_sleep:.1f} hrs\n")
            f.write(f"Current Streak Days   : {summary.current_streak_days}\n")
            f.write(f"Longest Streak Days   : {summary.longest_streak_days}\n")
            f.write(f"Best Day of Week      : {summary.best_day_of_week}\n")
            f.write(f"Worst Day of Week     : {summary.worst_day_of_week}\n\n")

            f.write("MOOD LABELS SUMMARY:\n")
            f.write("-" * 40 + "\n")
            for lbl, count in summary.mood_label_counts.items():
                pct = (count / max(1, summary.total_entries)) * 100
                f.write(f"  * {lbl:<20}: {count:>3} ({pct:>5.1f}%)\n")
            f.write("\n")

            f.write("ACTIVE WARNINGS & ANOMALIES:\n")
            f.write("-" * 40 + "\n")
            if alerts:
                for a in alerts:
                    f.write(f"[{a.severity}] {a.category} (Date: {a.date or 'N/A'})\n")
                    f.write(f"  Details: {a.message}\n")
                    f.write(f"  Advice : {a.recommendation}\n\n")
            else:
                f.write("  No warning flags detected.\n\n")

            f.write("RECORD AUDIT LOG:\n")
            f.write("-" * 72 + "\n")
            f.write(f"{'DATE':<11} {'TIME':<6} {'MOOD':<5} {'LABEL':<14} {'STRESS':<7} {'SLEEP':<6} {'TAGS'}\n")
            f.write("-" * 72 + "\n")
            for e in entries:
                tags_str = ";".join(e.tags)
                f.write(f"{e.date:<11} {e.time:<6} {e.mood_score:<5} {(e.mood_label or '-'):<14} {e.stress_level:<7} {e.sleep_hours:<6.1f} {tags_str}\n")
            f.write("=" * 72 + "\n")

        return out_path

    def export_json(
        self,
        entries: List[MoodEntry],
        summary: AggregateSummary,
        alerts: List[WarningAlert],
        filename: str
    ) -> Path:
        """Export full structured JSON summary."""
        out_path = self.exports_dir / filename
        payload = {
            "metadata": {
                "system": "Mood Journal Analyzer",
                "version": "1.0.0",
                "exported_at": datetime.now().isoformat(),
                "total_records": summary.total_entries,
                "date_range": summary.date_range_str,
            },
            "summary": {
                "wellness_status": summary.wellness_status,
                "mood_trend": summary.mood_trend,
                "avg_mood": summary.avg_mood,
                "min_mood": summary.min_mood,
                "max_mood": summary.max_mood,
                "mood_volatility": summary.mood_volatility,
                "avg_energy": summary.avg_energy,
                "avg_stress": summary.avg_stress,
                "avg_sleep": summary.avg_sleep,
                "current_streak_days": summary.current_streak_days,
                "longest_streak_days": summary.longest_streak_days,
                "best_day_of_week": summary.best_day_of_week,
                "worst_day_of_week": summary.worst_day_of_week,
                "mood_label_distribution": summary.mood_label_counts,
            },
            "warnings": [
                {
                    "severity": a.severity,
                    "category": a.category,
                    "message": a.message,
                    "date": a.date,
                    "recommendation": a.recommendation
                }
                for a in alerts
            ],
            "entries": [e.to_dict() for e in entries]
        }

        with open(out_path, mode="w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

        return out_path
