"""
Core Business Logic and Analytics Engine for Mood Journal Analyzer.
Calculates statistical metrics, moving averages, mood patterns, label distributions,
correlations, day-of-week trends, streaks, and executive summaries.
"""

import math
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple, Any
from collections import Counter, defaultdict

from src.models import MoodEntry, FilterCriteria, AggregateSummary


def filter_entries(entries: List[MoodEntry], criteria: FilterCriteria) -> List[MoodEntry]:
    """
    Filter entries based on multiple keyword and category constraints.
    """
    results = list(entries)

    if criteria.keyword:
        kw = criteria.keyword.strip().lower()
        results = [
            e for e in results
            if kw in e.notes.lower()
            or (e.mood_label and kw in e.mood_label.lower())
            or any(kw in t.lower() for t in e.tags)
            or kw in e.id.lower()
        ]

    if criteria.mood_label:
        target = criteria.mood_label.strip().lower()
        if target in ("unlabeled", "none", "blank", "empty"):
            results = [e for e in results if not e.mood_label]
        else:
            results = [e for e in results if e.mood_label and target in e.mood_label.lower()]

    if criteria.min_mood_score is not None:
        results = [e for e in results if e.mood_score >= criteria.min_mood_score]

    if criteria.max_mood_score is not None:
        results = [e for e in results if e.mood_score <= criteria.max_mood_score]

    if criteria.start_date:
        results = [e for e in results if e.date >= criteria.start_date]

    if criteria.end_date:
        results = [e for e in results if e.date <= criteria.end_date]

    if criteria.min_stress is not None:
        results = [e for e in results if e.stress_level >= criteria.min_stress]

    if criteria.max_stress is not None:
        results = [e for e in results if e.stress_level <= criteria.max_stress]

    if criteria.tag:
        t_clean = criteria.tag.strip().lower()
        results = [e for e in results if any(t_clean == t.lower() for t in e.tags)]

    return results


def calculate_standard_deviation(values: List[float]) -> float:
    """Calculate sample standard deviation."""
    n = len(values)
    if n < 2:
        return 0.0
    mean_val = sum(values) / n
    variance = sum((x - mean_val) ** 2 for x in values) / (n - 1)
    return round(math.sqrt(variance), 2)


def calculate_pearson_correlation(x: List[float], y: List[float]) -> float:
    """Calculate Pearson correlation coefficient between two numeric series."""
    n = len(x)
    if n < 3 or len(y) != n:
        return 0.0

    mean_x = sum(x) / n
    mean_y = sum(y) / n

    numerator = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
    denom_x = sum((xi - mean_x) ** 2 for xi in x)
    denom_y = sum((yi - mean_y) ** 2 for yi in y)

    denominator = math.sqrt(denom_x * denom_y)
    if denominator == 0:
        return 0.0

    return round(numerator / denominator, 3)


def determine_mood_trend(entries: List[MoodEntry]) -> str:
    """
    Evaluate direction of mood trajectory over chronological entries.
    Uses linear regression slope and rolling half comparisons.
    """
    if len(entries) < 3:
        return "Stable (Baseline)"

    scores = [float(e.mood_score) for e in entries]
    n = len(scores)
    x = list(range(n))
    mean_x = sum(x) / n
    mean_y = sum(scores) / n

    denom = sum((xi - mean_x) ** 2 for xi in x)
    if denom == 0:
        return "Stable"

    slope = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, scores)) / denom

    volatility = calculate_standard_deviation(scores)
    if volatility >= 2.5 and abs(slope) < 0.15:
        return "High Volatility (Fluctuating)"

    if slope >= 0.20:
        return "Sharply Improving ↗↗"
    elif slope >= 0.05:
        return "Gradually Improving ↗"
    elif slope <= -0.20:
        return "Sharply Declining ↘↘"
    elif slope <= -0.05:
        return "Gradually Declining ↘"
    else:
        return "Stable / Steady →"


def calculate_streaks(entries: List[MoodEntry]) -> Tuple[int, int, int]:
    """
    Calculate (current_streak_days, longest_streak_days, total_unique_days).
    """
    if not entries:
        return 0, 0, 0

    unique_dates = sorted(list(set(e.date for e in entries)))
    date_objs = [datetime.strptime(d, "%Y-%m-%d").date() for d in unique_dates]

    if not date_objs:
        return 0, 0, 0

    longest_streak = 1
    current_streak = 1

    # Compute longest streak in history
    temp_streak = 1
    for i in range(1, len(date_objs)):
        if (date_objs[i] - date_objs[i - 1]).days == 1:
            temp_streak += 1
            if temp_streak > longest_streak:
                longest_streak = temp_streak
        elif (date_objs[i] - date_objs[i - 1]).days > 1:
            temp_streak = 1

    # Compute current active streak ending at today or latest recorded entry
    latest_date = date_objs[-1]
    today = datetime.now().date()
    days_since_latest = (today - latest_date).days

    if days_since_latest > 1:
        # Streak broken
        current_streak = 0
    else:
        # Walk backwards
        curr = 1
        for i in range(len(date_objs) - 1, 0, -1):
            if (date_objs[i] - date_objs[i - 1]).days == 1:
                curr += 1
            else:
                break
        current_streak = curr

    return current_streak, max(longest_streak, current_streak), len(unique_dates)


def calculate_day_of_week_analysis(entries: List[MoodEntry]) -> Dict[str, Dict[str, Any]]:
    """
    Aggregate average mood, stress, and entry count by day of the week.
    """
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    day_buckets: Dict[str, List[MoodEntry]] = {d: [] for d in day_names}

    for e in entries:
        try:
            dt = datetime.strptime(e.date, "%Y-%m-%d")
            day_name = day_names[dt.weekday()]
            day_buckets[day_name].append(e)
        except Exception:
            continue

    analysis: Dict[str, Dict[str, Any]] = {}
    for d, bucket in day_buckets.items():
        if not bucket:
            analysis[d] = {"count": 0, "avg_mood": 0.0, "avg_stress": 0.0, "avg_energy": 0.0}
        else:
            analysis[d] = {
                "count": len(bucket),
                "avg_mood": round(sum(b.mood_score for b in bucket) / len(bucket), 1),
                "avg_stress": round(sum(b.stress_level for b in bucket) / len(bucket), 1),
                "avg_energy": round(sum(b.energy_level for b in bucket) / len(bucket), 1),
            }

    return analysis


def calculate_moving_averages(entries: List[MoodEntry], window: int = 3) -> List[Dict[str, Any]]:
    """
    Calculate chronological moving averages for mood, energy, and stress.
    """
    if not entries:
        return []

    sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))
    results = []

    for i in range(len(sorted_entries)):
        start_idx = max(0, i - window + 1)
        sub_window = sorted_entries[start_idx : i + 1]

        avg_m = sum(x.mood_score for x in sub_window) / len(sub_window)
        avg_e = sum(x.energy_level for x in sub_window) / len(sub_window)
        avg_s = sum(x.stress_level for x in sub_window) / len(sub_window)

        results.append({
            "entry_id": sorted_entries[i].id,
            "date": sorted_entries[i].date,
            "mood_score": sorted_entries[i].mood_score,
            "moving_avg_mood": round(avg_m, 2),
            "moving_avg_energy": round(avg_e, 2),
            "moving_avg_stress": round(avg_s, 2),
            "window_size": len(sub_window)
        })

    return results


def determine_wellness_status(
    avg_mood: float,
    avg_stress: float,
    avg_sleep: float,
    volatility: float
) -> Tuple[str, str]:
    """
    Determine holistic wellness health status and display color.
    Returns (status_title, color_code).
    """
    if avg_mood >= 7.5 and avg_stress <= 4.0 and avg_sleep >= 7.0:
        return "Thriving (Optimal Wellbeing)", "GREEN"
    elif avg_mood >= 6.0 and avg_stress <= 6.0:
        return "Balanced & Resilient", "CYAN"
    elif avg_stress >= 7.8 and avg_mood <= 4.5:
        return "Critical Burnout Risk", "RED"
    elif avg_stress >= 7.0:
        return "High Stress Alert", "MAGENTA"
    elif avg_mood <= 4.0:
        return "Persistent Low Mood", "RED"
    elif volatility >= 2.8:
        return "High Emotional Volatility", "YELLOW"
    else:
        return "Moderate / Needs Mindful Attention", "YELLOW"


def generate_executive_summary(entries: List[MoodEntry]) -> AggregateSummary:
    """
    Generate comprehensive executive summary of all or filtered mood records.
    """
    if not entries:
        return AggregateSummary()

    # Sort entries
    sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))

    n = len(sorted_entries)
    mood_scores = [float(e.mood_score) for e in sorted_entries]
    energy_scores = [float(e.energy_level) for e in sorted_entries]
    stress_scores = [float(e.stress_level) for e in sorted_entries]
    sleep_values = [float(e.sleep_hours) for e in sorted_entries]

    avg_mood = round(sum(mood_scores) / n, 2)
    min_mood = int(min(mood_scores))
    max_mood = int(max(mood_scores))
    avg_energy = round(sum(energy_scores) / n, 2)
    avg_stress = round(sum(stress_scores) / n, 2)
    avg_sleep = round(sum(sleep_values) / n, 2)

    # Volatility
    volatility = calculate_standard_deviation(mood_scores)

    # Mood labels distribution
    label_counter: Counter = Counter()
    for e in sorted_entries:
        lbl = e.mood_label if e.mood_label else "Unlabeled"
        label_counter[lbl] += 1

    # Streaks
    curr_streak, longest_streak, unique_days = calculate_streaks(sorted_entries)

    # Day of week best/worst
    dow = calculate_day_of_week_analysis(sorted_entries)
    valid_dows = {d: data["avg_mood"] for d, data in dow.items() if data["count"] > 0}
    if valid_dows:
        best_day = max(valid_dows.items(), key=lambda x: x[1])[0]
        worst_day = min(valid_dows.items(), key=lambda x: x[1])[0]
    else:
        best_day = "N/A"
        worst_day = "N/A"

    # Mood trend
    trend = determine_mood_trend(sorted_entries)

    # Wellness status
    status, color = determine_wellness_status(avg_mood, avg_stress, avg_sleep, volatility)

    date_range_str = f"{sorted_entries[0].date} to {sorted_entries[-1].date}"

    return AggregateSummary(
        total_entries=n,
        avg_mood=avg_mood,
        min_mood=min_mood,
        max_mood=max_mood,
        avg_energy=avg_energy,
        avg_stress=avg_stress,
        avg_sleep=avg_sleep,
        mood_label_counts=dict(label_counter.most_common()),
        mood_volatility=volatility,
        mood_trend=trend,
        wellness_status=status,
        wellness_indicator_color=color,
        best_day_of_week=best_day,
        worst_day_of_week=worst_day,
        current_streak_days=curr_streak,
        longest_streak_days=longest_streak,
        days_logged=unique_days,
        date_range_str=date_range_str,
    )
