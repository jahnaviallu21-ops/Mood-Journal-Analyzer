"""
Bulk Dataset Import Engine for Mood Journal Analyzer.
Ingests legacy or external CSV datasets with flexible header mapping,
automatic format validation, and detailed row-by-row audit logs.
"""

import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass, field

from src.models import MoodEntry
from src.validator import validate_entry_dict

logger = logging.getLogger(__name__)

# Flexible column aliases for legacy datasets
HEADER_ALIASES = {
    "id": ["id", "entry_id", "record_id", "key", "journal_id"],
    "date": ["date", "entry_date", "timestamp_date", "day", "logged_date"],
    "time": ["time", "entry_time", "hour", "logged_time"],
    "mood_score": ["mood_score", "mood", "score", "mood_rating", "rating", "mood_level"],
    "mood_label": ["mood_label", "label", "feeling", "emotion", "state", "mood_tag"],
    "energy_level": ["energy_level", "energy", "vitality", "energy_score", "energy_rating"],
    "stress_level": ["stress_level", "stress", "tension", "stress_score", "anxiety_level"],
    "sleep_hours": ["sleep_hours", "sleep", "hours_slept", "sleep_duration", "hours_of_sleep"],
    "tags": ["tags", "categories", "activities", "context", "tag_list"],
    "notes": ["notes", "note", "reflection", "journal", "comment", "description", "details"],
}


@dataclass
class RowImportReport:
    row_number: int
    status: str  # "ACCEPTED", "CORRECTED", "REJECTED"
    raw_data: Dict[str, str]
    errors: List[str] = field(default_factory=list)
    entry: Optional[MoodEntry] = None


@dataclass
class BulkImportSummary:
    total_rows: int = 0
    accepted_count: int = 0
    rejected_count: int = 0
    log_file_path: Optional[str] = None
    row_reports: List[RowImportReport] = field(default_factory=list)
    imported_entries: List[MoodEntry] = field(default_factory=list)


def normalize_headers(raw_headers: List[str]) -> Dict[str, str]:
    """
    Map raw CSV headers to standard MoodEntry schema fields.
    Returns mapping: {standard_field_name: raw_csv_header}.
    """
    cleaned_headers = {h.strip().lower().replace(" ", "_"): h for h in raw_headers}
    mapping: Dict[str, str] = {}

    for standard_field, aliases in HEADER_ALIASES.items():
        for alias in aliases:
            if alias in cleaned_headers:
                mapping[standard_field] = cleaned_headers[alias]
                break

    return mapping


class BulkImporter:
    """Handles ingestion of external CSV files with defensive row validation."""

    def __init__(self, exports_dir: Optional[Path] = None):
        if exports_dir:
            self.exports_dir = exports_dir
        else:
            self.exports_dir = Path(__file__).resolve().parent.parent / "exports"
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def import_csv_file(self, file_path: str, dry_run: bool = False) -> BulkImportSummary:
        """
        Parse and validate a CSV dataset row-by-row.
        Generates a detailed audit log report.
        """
        p = Path(file_path)
        if not p.exists():
            raise FileNotFoundError(f"Import file does not exist: {file_path}")

        summary = BulkImportSummary()
        reports: List[RowImportReport] = []
        valid_entries: List[MoodEntry] = []

        try:
            with open(p, mode="r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    raise ValueError(f"CSV file '{p.name}' is empty or lacks headers.")

                mapping = normalize_headers(list(reader.fieldnames))

                # Check if minimum required fields can be resolved
                if "date" not in mapping or "mood_score" not in mapping:
                    raise ValueError(
                        f"Missing essential columns. Found headers: {reader.fieldnames}. "
                        "Dataset must at least contain columns mappable to 'date' and 'mood_score'."
                    )

                for row_idx, raw_row in enumerate(reader, start=2):
                    summary.total_rows += 1

                    # Transform row using header mapping
                    standardized: Dict[str, Any] = {}
                    for std_field, raw_col in mapping.items():
                        standardized[std_field] = raw_row.get(raw_col, "")

                    # Fallbacks for missing optional columns
                    if "time" not in standardized or not standardized["time"]:
                        standardized["time"] = "12:00"
                    if "energy_level" not in standardized or not standardized["energy_level"]:
                        standardized["energy_level"] = 5
                    if "stress_level" not in standardized or not standardized["stress_level"]:
                        standardized["stress_level"] = 5
                    if "sleep_hours" not in standardized or not standardized["sleep_hours"]:
                        standardized["sleep_hours"] = 7.0
                    if "tags" not in standardized:
                        standardized["tags"] = []

                    is_valid, field_errs, cleaned_dict = validate_entry_dict(standardized)

                    if is_valid and cleaned_dict:
                        entry = MoodEntry.from_dict(cleaned_dict)
                        status = "ACCEPTED"
                        rep = RowImportReport(
                            row_number=row_idx,
                            status=status,
                            raw_data=dict(raw_row),
                            errors=[],
                            entry=entry,
                        )
                        reports.append(rep)
                        valid_entries.append(entry)
                        summary.accepted_count += 1
                    else:
                        status = "REJECTED"
                        err_msgs = [f"Field '{k}': {v}" for k, v in field_errs.items()]
                        rep = RowImportReport(
                            row_number=row_idx,
                            status=status,
                            raw_data=dict(raw_row),
                            errors=err_msgs,
                            entry=None,
                        )
                        reports.append(rep)
                        summary.rejected_count += 1

        except Exception as e:
            logger.error(f"Error parsing CSV import: {e}")
            raise

        summary.row_reports = reports
        summary.imported_entries = valid_entries

        # Generate audit log file
        log_file = self._write_import_audit_log(p.name, summary)
        summary.log_file_path = str(log_file)

        return summary

    def _write_import_audit_log(self, filename: str, summary: BulkImportSummary) -> Path:
        """Create structured import log file."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"import_log_{Path(filename).stem}_{ts}.txt"
        log_path = self.exports_dir / log_filename

        with open(log_path, mode="w", encoding="utf-8") as f:
            f.write("=" * 70 + "\n")
            f.write("MOOD JOURNAL ANALYZER - BULK DATASET INGESTION AUDIT LOG\n")
            f.write(f"Source File: {filename}\n")
            f.write(f"Timestamp  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Rows : {summary.total_rows}\n")
            f.write(f"Accepted   : {summary.accepted_count} rows ({(summary.accepted_count / max(1, summary.total_rows))*100:.1f}%)\n")
            f.write(f"Rejected   : {summary.rejected_count} rows ({(summary.rejected_count / max(1, summary.total_rows))*100:.1f}%)\n")
            f.write("=" * 70 + "\n\n")

            f.write("ROW-BY-ROW VALIDATION DETAILS:\n")
            f.write("-" * 70 + "\n")
            for rep in summary.row_reports:
                f.write(f"Row {rep.row_number:03d} | [{rep.status}] ")
                if rep.status == "ACCEPTED" and rep.entry:
                    f.write(f"ID={rep.entry.id} | Date={rep.entry.date} | Mood={rep.entry.mood_score} | Label={rep.entry.mood_label or 'None'}\n")
                else:
                    f.write(f"REASON: {'; '.join(rep.errors)}\n")
                    f.write(f"         Raw Payload: {rep.raw_data}\n")

            f.write("\n" + "=" * 70 + "\n")
            f.write("END OF AUDIT LOG\n")

        return log_path
