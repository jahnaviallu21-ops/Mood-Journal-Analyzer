"""
Visual Data Plotting Engine for Mood Journal Analyzer.
Generates publication-quality charts using Matplotlib with defensive fallback
to ASCII/Unicode terminal graphs when running in headless or non-GUI environments.
"""

import os
import sys
import logging
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

from src.models import MoodEntry
from src.analytics import (
    calculate_moving_averages,
    calculate_day_of_week_analysis,
    calculate_pearson_correlation,
)

logger = logging.getLogger(__name__)

# Ensure Matplotlib temp directory is set cleanly
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent.parent / "exports" / ".mplcache"))

MATPLOTLIB_AVAILABLE = False
try:
    import matplotlib
    # Use non-interactive backend by default for file rendering safety
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    MATPLOTLIB_AVAILABLE = True
except (ImportError, Exception) as e:
    logger.warning(f"Matplotlib not available or failed to load ({e}). Using terminal ASCII visual fallback.")


# Calming, professional wellness color palette
PALETTE = {
    "primary": "#4A6FA5",      # Slate Indigo
    "secondary": "#166088",    # Deep Teal
    "accent_good": "#4EBA6F",  # Calming Emerald Green
    "accent_bad": "#E05A47",   # Warm Coral Red
    "accent_warn": "#EBB15B",  # Muted Amber
    "accent_purple": "#7D6B9D",# Lavender
    "bg_card": "#F8FAFC",      # Clean Slate Off-White
    "grid": "#E2E8F0",         # Soft Border
    "text": "#1E293B",         # Deep Slate Charcoal
}


class MoodPlotter:
    """Produces visual distribution and trend charts."""

    def __init__(self, exports_dir: Optional[Path] = None):
        if exports_dir:
            self.exports_dir = exports_dir
        else:
            self.exports_dir = Path(__file__).resolve().parent.parent / "exports"
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    @property
    def is_available(self) -> bool:
        """Check if Matplotlib is ready for graphical rendering."""
        return MATPLOTLIB_AVAILABLE

    def generate_all_plots(self, entries: List[MoodEntry], base_name: str = "mood_report") -> Dict[str, str]:
        """
        Generate all visualizations and save them to the exports directory.
        Returns dictionary mapping chart names to image file paths.
        """
        if not entries:
            return {}

        results: Dict[str, str] = {}

        if not MATPLOTLIB_AVAILABLE:
            logger.info("Matplotlib not detected. Graphical plot generation skipped.")
            return results

        try:
            # 1. Unified 2x2 Executive Dashboard
            dash_path = self.exports_dir / f"{base_name}_dashboard.png"
            self.plot_executive_dashboard(entries, str(dash_path))
            results["dashboard"] = str(dash_path)

            # 2. Time-series Trend Chart
            trend_path = self.exports_dir / f"{base_name}_trend.png"
            self.plot_mood_timeline(entries, str(trend_path))
            results["trend"] = str(trend_path)

            # 3. Mood Label Distribution
            dist_path = self.exports_dir / f"{base_name}_distribution.png"
            self.plot_label_distribution(entries, str(dist_path))
            results["distribution"] = str(dist_path)

            # 4. Sleep vs Mood Scatter
            sleep_path = self.exports_dir / f"{base_name}_sleep_vs_mood.png"
            self.plot_sleep_vs_mood(entries, str(sleep_path))
            results["sleep_vs_mood"] = str(sleep_path)

            # 5. Day of Week Analysis
            dow_path = self.exports_dir / f"{base_name}_day_of_week.png"
            self.plot_day_of_week(entries, str(dow_path))
            results["day_of_week"] = str(dow_path)

        except Exception as e:
            logger.error(f"Error generating visual plots: {e}")

        return results

    def plot_executive_dashboard(self, entries: List[MoodEntry], out_path: str) -> None:
        """Create a 4-panel comprehensive visual dashboard."""
        if not MATPLOTLIB_AVAILABLE or not entries:
            return

        sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))

        fig, axs = plt.subplots(2, 2, figsize=(15, 11), facecolor="#FFFFFF")
        fig.suptitle(
            "Mood Journal Analyzer - Visual Analytics Dashboard",
            fontsize=18,
            fontweight="bold",
            color=PALETTE["text"],
            y=0.98
        )

        # Panel 1: Mood & Stress Over Time (Top-Left)
        dates = [f"{e.date[5:]}" for e in sorted_entries]
        moods = [e.mood_score for e in sorted_entries]
        stress = [e.stress_level for e in sorted_entries]
        indices = list(range(len(sorted_entries)))

        ax1 = axs[0, 0]
        ax1.set_facecolor(PALETTE["bg_card"])
        ax1.plot(indices, moods, marker="o", color=PALETTE["primary"], linewidth=2.5, label="Mood Score (1-10)")
        ax1.plot(indices, stress, marker="s", color=PALETTE["accent_bad"], linewidth=2.0, linestyle="--", label="Stress Level (1-10)")

        # Moving average
        ma = calculate_moving_averages(sorted_entries, window=3)
        if len(ma) > 2:
            ma_mood = [item["moving_avg_mood"] for item in ma]
            ax1.plot(indices, ma_mood, color=PALETTE["accent_good"], linewidth=1.8, linestyle=":", label="3-Pt Moving Avg")

        ax1.set_title("Mood & Stress Trajectory Over Time", fontsize=12, fontweight="bold", color=PALETTE["text"])
        ax1.set_ylim(0.5, 10.5)
        ax1.set_ylabel("Rating (1 - 10)", fontsize=10)
        ax1.set_xticks(indices[::max(1, len(indices) // 8)])
        ax1.set_xticklabels([dates[i] for i in indices[::max(1, len(indices) // 8)]], rotation=30, fontsize=8)
        ax1.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"])
        ax1.legend(loc="upper left", fontsize=8)

        # Panel 2: Mood Label Breakdown (Top-Right)
        ax2 = axs[0, 1]
        ax2.set_facecolor(PALETTE["bg_card"])
        label_counts: Dict[str, int] = {}
        for e in sorted_entries:
            lbl = e.mood_label if e.mood_label else "Unlabeled"
            label_counts[lbl] = label_counts.get(lbl, 0) + 1

        top_labels = sorted(label_counts.items(), key=lambda x: x[1], reverse=True)[:7]
        labels = [item[0] for item in top_labels]
        counts = [item[1] for item in top_labels]

        colors = [
            PALETTE["primary"], PALETTE["accent_good"], PALETTE["secondary"],
            PALETTE["accent_warn"], PALETTE["accent_purple"], "#47A8BD", "#95A5A6"
        ][:len(labels)]

        wedges, texts, autotexts = ax2.pie(
            counts,
            labels=labels,
            autopct="%1.1f%%",
            startangle=140,
            colors=colors,
            wedgeprops={"edgecolor": "white", "linewidth": 1.5, "width": 0.6}
        )
        for t in texts:
            t.set_fontsize(9)
            t.set_color(PALETTE["text"])
        for at in autotexts:
            at.set_fontsize(8)
            at.set_color("#FFFFFF")
            at.set_weight("bold")
        ax2.set_title("Frequent Mood Labels Distribution", fontsize=12, fontweight="bold", color=PALETTE["text"])

        # Panel 3: Sleep Hours vs Mood Score (Bottom-Left)
        ax3 = axs[1, 0]
        ax3.set_facecolor(PALETTE["bg_card"])
        sleeps = [e.sleep_hours for e in sorted_entries]
        corr = calculate_pearson_correlation(sleeps, [float(m) for m in moods])

        ax3.scatter(sleeps, moods, color=PALETTE["secondary"], alpha=0.7, edgecolors="white", s=65, label=f"Entries (r = {corr:+.2f})")
        # Trendline if points exist
        if len(sleeps) > 2 and max(sleeps) != min(sleeps):
            x_vals = sorted(list(set(sleeps)))
            # Simple regression slope
            mean_s = sum(sleeps) / len(sleeps)
            mean_m = sum(moods) / len(moods)
            num = sum((s - mean_s) * (m - mean_m) for s, m in zip(sleeps, moods))
            den = sum((s - mean_s) ** 2 for s in sleeps)
            if den != 0:
                slope = num / den
                intercept = mean_m - slope * mean_s
                reg_y = [slope * xv + intercept for xv in x_vals]
                ax3.plot(x_vals, reg_y, color=PALETTE["accent_bad"], linestyle="--", linewidth=1.8, label="Trendline")

        ax3.set_title("Sleep Hours vs. Mood Rating Correlation", fontsize=12, fontweight="bold", color=PALETTE["text"])
        ax3.set_xlabel("Hours of Sleep", fontsize=10)
        ax3.set_ylabel("Mood Rating (1 - 10)", fontsize=10)
        ax3.set_ylim(0.5, 10.5)
        ax3.set_xlim(max(0, min(sleeps) - 1), min(24, max(sleeps) + 1))
        ax3.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"])
        ax3.legend(loc="upper left", fontsize=8)

        # Panel 4: Day of Week Average Mood (Bottom-Right)
        ax4 = axs[1, 1]
        ax4.set_facecolor(PALETTE["bg_card"])
        dow = calculate_day_of_week_analysis(sorted_entries)
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        full_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        avg_dow_moods = [dow[fd]["avg_mood"] for fd in full_days]

        bar_colors = []
        for val in avg_dow_moods:
            if val >= 7.0:
                bar_colors.append(PALETTE["accent_good"])
            elif val >= 5.0:
                bar_colors.append(PALETTE["primary"])
            else:
                bar_colors.append(PALETTE["accent_warn"])

        bars = ax4.bar(days, avg_dow_moods, color=bar_colors, edgecolor="white", width=0.55)
        for b in bars:
            h = b.get_height()
            if h > 0:
                ax4.annotate(f"{h:.1f}",
                    xy=(b.get_x() + b.get_width() / 2, h),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha="center", va="bottom", fontsize=8, fontweight="bold")

        ax4.set_title("Average Mood by Day of Week", fontsize=12, fontweight="bold", color=PALETTE["text"])
        ax4.set_ylabel("Avg Mood (1 - 10)", fontsize=10)
        ax4.set_ylim(0, 11)
        ax4.grid(True, axis="y", linestyle="--", alpha=0.6, color=PALETTE["grid"])

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig(out_path, dpi=200, facecolor="#FFFFFF")
        plt.close(fig)

    def plot_mood_timeline(self, entries: List[MoodEntry], out_path: str) -> None:
        """Standalone high-res timeline chart."""
        if not MATPLOTLIB_AVAILABLE or not entries:
            return

        sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))
        indices = list(range(len(sorted_entries)))
        moods = [e.mood_score for e in sorted_entries]
        stress = [e.stress_level for e in sorted_entries]
        dates = [e.date[5:] for e in sorted_entries]

        fig, ax = plt.subplots(figsize=(12, 6), facecolor="#FFFFFF")
        ax.set_facecolor(PALETTE["bg_card"])

        ax.plot(indices, moods, marker="o", color=PALETTE["primary"], linewidth=2.5, label="Mood Score")
        ax.plot(indices, stress, marker="s", color=PALETTE["accent_bad"], linewidth=2.0, linestyle="--", label="Stress Level")

        ax.set_title("Mood Journal Analyzer - Longitudinal Mood & Stress Trajectory", fontsize=14, fontweight="bold", color=PALETTE["text"])
        ax.set_ylabel("Rating (1-10 Scale)", fontsize=11)
        ax.set_ylim(0.5, 10.5)
        ax.set_xticks(indices[::max(1, len(indices) // 10)])
        ax.set_xticklabels([dates[i] for i in indices[::max(1, len(indices) // 10)]], rotation=35)
        ax.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"])
        ax.legend(loc="upper right", frameon=True)

        plt.tight_layout()
        plt.savefig(out_path, dpi=180, facecolor="#FFFFFF")
        plt.close(fig)

    def plot_label_distribution(self, entries: List[MoodEntry], out_path: str) -> None:
        """Standalone mood label distribution chart."""
        if not MATPLOTLIB_AVAILABLE or not entries:
            return

        counts: Dict[str, int] = {}
        for e in entries:
            lbl = e.mood_label if e.mood_label else "Unlabeled"
            counts[lbl] = counts.get(lbl, 0) + 1

        sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:8]
        labels = [x[0] for x in sorted_counts]
        vals = [x[1] for x in sorted_counts]

        fig, ax = plt.subplots(figsize=(8, 6), facecolor="#FFFFFF")
        ax.set_facecolor(PALETTE["bg_card"])

        wedges, texts, autotexts = ax.pie(
            vals,
            labels=labels,
            autopct="%1.1f%%",
            startangle=90,
            colors=[PALETTE["primary"], PALETTE["accent_good"], PALETTE["accent_warn"], PALETTE["accent_purple"], PALETTE["secondary"]][:len(labels)],
            wedgeprops={"edgecolor": "white", "linewidth": 2}
        )
        for at in autotexts:
            at.set_color("white")
            at.set_weight("bold")

        ax.set_title("Mood Label Frequency Distribution", fontsize=13, fontweight="bold", color=PALETTE["text"])
        plt.tight_layout()
        plt.savefig(out_path, dpi=180, facecolor="#FFFFFF")
        plt.close(fig)

    def plot_sleep_vs_mood(self, entries: List[MoodEntry], out_path: str) -> None:
        """Standalone sleep hours vs mood score scatter plot."""
        if not MATPLOTLIB_AVAILABLE or not entries:
            return

        sleeps = [e.sleep_hours for e in entries]
        moods = [e.mood_score for e in entries]

        fig, ax = plt.subplots(figsize=(8, 6), facecolor="#FFFFFF")
        ax.set_facecolor(PALETTE["bg_card"])

        ax.scatter(sleeps, moods, color=PALETTE["secondary"], s=70, alpha=0.75, edgecolors="white")
        ax.set_title("Relationship: Sleep Duration vs. Mood Score", fontsize=13, fontweight="bold", color=PALETTE["text"])
        ax.set_xlabel("Hours of Sleep", fontsize=11)
        ax.set_ylabel("Mood Score (1-10)", fontsize=11)
        ax.set_ylim(0.5, 10.5)
        ax.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"])

        plt.tight_layout()
        plt.savefig(out_path, dpi=180, facecolor="#FFFFFF")
        plt.close(fig)

    def plot_day_of_week(self, entries: List[MoodEntry], out_path: str) -> None:
        """Standalone day of week bar chart."""
        if not MATPLOTLIB_AVAILABLE or not entries:
            return

        dow = calculate_day_of_week_analysis(entries)
        full_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        avg_moods = [dow[d]["avg_mood"] for d in full_days]

        fig, ax = plt.subplots(figsize=(9, 5), facecolor="#FFFFFF")
        ax.set_facecolor(PALETTE["bg_card"])

        ax.bar([d[:3] for d in full_days], avg_moods, color=PALETTE["primary"], edgecolor="white", width=0.5)
        ax.set_title("Average Mood Score by Day of the Week", fontsize=13, fontweight="bold", color=PALETTE["text"])
        ax.set_ylabel("Average Mood (1-10)", fontsize=11)
        ax.set_ylim(0, 11)
        ax.grid(True, axis="y", linestyle="--", alpha=0.6, color=PALETTE["grid"])

        plt.tight_layout()
        plt.savefig(out_path, dpi=180, facecolor="#FFFFFF")
        plt.close(fig)

    @staticmethod
    def render_terminal_ascii_chart(entries: List[MoodEntry], width: int = 40, height: int = 10) -> str:
        """
        Generate a pure text/Unicode ASCII trend graph for terminal display.
        Guaranteed to work in any console without GUI or graphical dependencies.
        """
        if not entries:
            return "  [No entries to plot]"

        sorted_entries = sorted(entries, key=lambda x: (x.date, x.time))
        # Take latest entries up to width
        recent = sorted_entries[-width:]
        scores = [e.mood_score for e in recent]

        min_score = 1
        max_score = 10

        lines: List[str] = []
        lines.append("   ▲ Mood Rating (1 - 10 Scale)")
        lines.append("10 ┤")

        for row in range(height, 0, -1):
            threshold = (row / height) * (max_score - min_score) + min_score
            row_label = f"{int(threshold):2d} ┤ " if row in (height, height // 2, 1) else "   │ "
            row_chars = []
            for score in scores:
                scaled_y = ((score - min_score) / (max_score - min_score)) * height
                if abs(scaled_y - row) < 0.6:
                    row_chars.append("●")
                elif scaled_y > row:
                    row_chars.append("│")
                else:
                    row_chars.append(" ")
            lines.append(row_label + "".join(row_chars))

        lines.append(" 1 ┼" + "─" * len(scores) + "► Time")
        # Dates at bottom
        if len(recent) >= 2:
            d_start = recent[0].date[5:]
            d_end = recent[-1].date[5:]
            padding = max(0, len(scores) - len(d_start) - len(d_end))
            lines.append(f"    {d_start}{' ' * padding}{d_end}")

        return "\n".join(lines)
