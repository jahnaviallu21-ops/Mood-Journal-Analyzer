"""
Script to generate realistic seed datasets (JSON, CSV, and legacy import sample).
Includes normal entries, boundary values, and edge conditions (30-50 records).
"""

import json
import csv
from datetime import datetime, date, timedelta
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent

SAMPLE_ENTRIES = [
    # Baseline week 1 (Normal, stable)
    {"id": "MJ-2026-001", "date": "2026-10-15", "time": "08:30", "mood_score": 7, "mood_label": "Calm", "energy_level": 7, "stress_level": 3, "sleep_hours": 7.5, "tags": ["morning", "meditation", "work"], "notes": "Felt grounded starting the day. Morning coffee and planning session went smoothly."},
    {"id": "MJ-2026-002", "date": "2026-10-16", "time": "20:45", "mood_score": 8, "mood_label": "Content", "energy_level": 6, "stress_level": 4, "sleep_hours": 8.0, "tags": ["work", "exercise"], "notes": "Completed project deliverables ahead of schedule. Went for a sunset jog."},
    {"id": "MJ-2026-003", "date": "2026-10-17", "time": "21:15", "mood_score": 6, "mood_label": "Neutral", "energy_level": 5, "stress_level": 5, "sleep_hours": 6.8, "tags": ["routine", "reading"], "notes": "Average Friday. Unwound with a chapter of science fiction."},
    {"id": "MJ-2026-004", "date": "2026-10-18", "time": "14:00", "mood_score": 9, "mood_label": "Joyful", "energy_level": 8, "stress_level": 2, "sleep_hours": 8.5, "tags": ["weekend", "family", "outdoors"], "notes": "Brilliant weekend hike with family. Refreshing autumn air."},
    {"id": "MJ-2026-005", "date": "2026-10-19", "time": "19:30", "mood_score": 8, "mood_label": "Motivated", "energy_level": 8, "stress_level": 3, "sleep_hours": 7.8, "tags": ["planning", "hobbies"], "notes": "Prepped meals and organized desk for the upcoming work week."},

    # Week 2 (Normal progression + Edge: Unlabeled mood entry)
    {"id": "MJ-2026-006", "date": "2026-10-20", "time": "09:00", "mood_score": 7, "mood_label": None, "energy_level": 7, "stress_level": 4, "sleep_hours": 7.2, "tags": ["work", "meetings"], "notes": "Standard Monday syncs. Mood felt okay, didn't feel like choosing a specific label."},
    {"id": "MJ-2026-007", "date": "2026-10-21", "time": "21:00", "mood_score": 7, "mood_label": "Content", "energy_level": 6, "stress_level": 4, "sleep_hours": 7.0, "tags": ["coding", "learning"], "notes": "Built clean architecture diagrams today. Steady progress."},
    {"id": "MJ-2026-008", "date": "2026-10-22", "time": "18:20", "mood_score": 6, "mood_label": "Neutral", "energy_level": 5, "stress_level": 5, "sleep_hours": 6.5, "tags": ["routine"], "notes": "Midweek fatigue setting in slightly."},
    {"id": "MJ-2026-009", "date": "2026-10-23", "time": "22:00", "mood_score": 5, "mood_label": "Restless", "energy_level": 4, "stress_level": 6, "sleep_hours": 6.0, "tags": ["deadline", "screen-time"], "notes": "Stared at screens too late into the evening. Brain felt busy."},
    {"id": "MJ-2026-010", "date": "2026-10-24", "time": "17:40", "mood_score": 7, "mood_label": "Calm", "energy_level": 6, "stress_level": 3, "sleep_hours": 7.5, "tags": ["weekend", "social"], "notes": "Dinner with friends helped clear my mind."},

    # Boundary Value 1: Peak Mood (10/10) & Maximum Energy (10/10)
    {"id": "MJ-2026-011", "date": "2026-10-25", "time": "15:30", "mood_score": 10, "mood_label": "Joyful", "energy_level": 10, "stress_level": 1, "sleep_hours": 9.0, "tags": ["celebration", "milestone", "outdoor"], "notes": "Boundary test: Maximum mood rating 10! Won hackathon innovation grant. Euphoric energy!"},

    # Week 3: Academic/Work Crunch Period (Stress rising, Sleep dropping)
    {"id": "MJ-2026-012", "date": "2026-10-26", "time": "08:15", "mood_score": 6, "mood_label": "Motivated", "energy_level": 7, "stress_level": 6, "sleep_hours": 6.5, "tags": ["work", "sprint"], "notes": "Sprint review approaching. Lots to coordinate."},
    {"id": "MJ-2026-013", "date": "2026-10-27", "time": "22:45", "mood_score": 5, "mood_label": "Anxious", "energy_level": 5, "stress_level": 7, "sleep_hours": 5.8, "tags": ["work", "deadlines"], "notes": "Surprise roadblocks in testing. Had to debug into late evening."},
    {"id": "MJ-2026-014", "date": "2026-10-28", "time": "23:30", "mood_score": 4, "mood_label": "Stressed", "energy_level": 4, "stress_level": 8, "sleep_hours": 5.0, "tags": ["crunch", "exam"], "notes": "High pressure day. Felt tense during presentations."},
    {"id": "MJ-2026-015", "date": "2026-10-29", "time": "23:50", "mood_score": 3, "mood_label": "Exhausted", "energy_level": 3, "stress_level": 8, "sleep_hours": 4.5, "tags": ["fatigue", "overtime"], "notes": "Sleep deprivation accumulating. Need to protect bedtime."},

    # Boundary Value 2: Minimum Mood (1/10), Maximum Stress (10/10), Severe Sleep Deficit (3.0h)
    {"id": "MJ-2026-016", "date": "2026-10-30", "time": "07:30", "mood_score": 1, "mood_label": "Overwhelmed", "energy_level": 1, "stress_level": 10, "sleep_hours": 3.0, "tags": ["crisis", "exhaustion", "boundary"], "notes": "Boundary test: Minimum mood 1, Maximum stress 10, Sleep 3.0h. Server crash midnight, totally drained."},

    # Recovery Phase: Sleep Bounceback & Stress Alleviation
    {"id": "MJ-2026-017", "date": "2026-10-31", "time": "12:00", "mood_score": 4, "mood_label": "Fatigued", "energy_level": 3, "stress_level": 6, "sleep_hours": 10.5, "tags": ["recovery", "rest"], "notes": "Slept over 10 hours to recover. Body aches easing up."},
    {"id": "MJ-2026-018", "date": "2026-11-01", "time": "16:00", "mood_score": 6, "mood_label": "Calm", "energy_level": 5, "stress_level": 4, "sleep_hours": 8.5, "tags": ["walk", "recharge"], "notes": "Took long walk in the botanical garden. Stress significantly lowered."},
    {"id": "MJ-2026-019", "date": "2026-11-02", "time": "20:00", "mood_score": 7, "mood_label": "Content", "energy_level": 6, "stress_level": 3, "sleep_hours": 7.8, "tags": ["reading", "tea"], "notes": "Peaceful Sunday evening preparing for the new month."},

    # Week 4: Healthy Rhythm (Edge cases: Custom mood labels & empty tags)
    {"id": "MJ-2026-020", "date": "2026-11-03", "time": "08:45", "mood_score": 7, "mood_label": "Focused", "energy_level": 7, "stress_level": 4, "sleep_hours": 7.5, "tags": ["work", "focus"], "notes": "Edge test: Custom label 'Focused'. Deep work block on algorithms."},
    {"id": "MJ-2026-021", "date": "2026-11-04", "time": "18:00", "mood_score": 8, "mood_label": "Grateful", "energy_level": 7, "stress_level": 3, "sleep_hours": 8.0, "tags": ["gratitude", "social"], "notes": "Expressed appreciation to study partners for their support."},
    {"id": "MJ-2026-022", "date": "2026-11-05", "time": "21:30", "mood_score": 7, "mood_label": None, "energy_level": 6, "stress_level": 4, "sleep_hours": 7.0, "tags": [], "notes": "Edge test: No tags provided. Routine day without drama."},
    {"id": "MJ-2026-023", "date": "2026-11-06", "time": "19:00", "mood_score": 8, "mood_label": "Energetic", "energy_level": 9, "stress_level": 3, "sleep_hours": 7.5, "tags": ["gym", "workout"], "notes": "Hit personal record in deadlift. High dopamine."},
    {"id": "MJ-2026-024", "date": "2026-11-07", "time": "22:15", "mood_score": 8, "mood_label": "Content", "energy_level": 7, "stress_level": 2, "sleep_hours": 8.0, "tags": ["weekend", "music"], "notes": "Attended an acoustic guitar concert."},
    {"id": "MJ-2026-025", "date": "2026-11-08", "time": "16:30", "mood_score": 9, "mood_label": "Joyful", "energy_level": 8, "stress_level": 2, "sleep_hours": 8.5, "tags": ["family", "baking"], "notes": "Baked sourdough bread and shared with neighbors."},

    # Week 5: Steady Productivity
    {"id": "MJ-2026-026", "date": "2026-11-09", "time": "09:10", "mood_score": 7, "mood_label": "Calm", "energy_level": 7, "stress_level": 3, "sleep_hours": 7.4, "tags": ["morning", "work"], "notes": "Solid kickoff to the sprint."},
    {"id": "MJ-2026-027", "date": "2026-11-10", "time": "20:00", "mood_score": 8, "mood_label": "Motivated", "energy_level": 8, "stress_level": 4, "sleep_hours": 7.6, "tags": ["coding", "innovation"], "notes": "Refactored the data persistence pipeline with unit tests."},
    {"id": "MJ-2026-028", "date": "2026-11-11", "time": "21:40", "mood_score": 7, "mood_label": "Content", "energy_level": 6, "stress_level": 3, "sleep_hours": 7.2, "tags": ["reading"], "notes": "Reviewed papers on positive psychology."},
    {"id": "MJ-2026-029", "date": "2026-11-12", "time": "19:15", "mood_score": 6, "mood_label": "Neutral", "energy_level": 5, "stress_level": 5, "sleep_hours": 6.8, "tags": ["chores"], "notes": "Spent evening cleaning apartment and sorting paperwork."},
    {"id": "MJ-2026-030", "date": "2026-11-13", "time": "22:00", "mood_score": 8, "mood_label": "Joyful", "energy_level": 7, "stress_level": 3, "sleep_hours": 7.5, "tags": ["friends", "boardgames"], "notes": "Board game night with classmates."},

    # Boundary Value 3: Extreme Sleep Duration (12.0h)
    {"id": "MJ-2026-031", "date": "2026-11-14", "time": "13:00", "mood_score": 7, "mood_label": "Rested", "energy_level": 6, "stress_level": 2, "sleep_hours": 12.0, "tags": ["sleep", "boundary"], "notes": "Boundary test: 12.0 hours sleep. Caught up completely on sleep debt."},

    # Week 6: Recent Tracking Streak (November 15 to November 21)
    {"id": "MJ-2026-032", "date": "2026-11-15", "time": "21:00", "mood_score": 8, "mood_label": "Calm", "energy_level": 7, "stress_level": 2, "sleep_hours": 8.0, "tags": ["meditation", "planning"], "notes": "Peaceful Sunday evening."},
    {"id": "MJ-2026-033", "date": "2026-11-16", "time": "08:30", "mood_score": 7, "mood_label": "Motivated", "energy_level": 8, "stress_level": 3, "sleep_hours": 7.5, "tags": ["work", "goals"], "notes": "Set clear sprint milestones for the final week."},
    {"id": "MJ-2026-034", "date": "2026-11-17", "time": "18:30", "mood_score": 8, "mood_label": "Joyful", "energy_level": 8, "stress_level": 3, "sleep_hours": 7.8, "tags": ["demo", "success"], "notes": "Mentor loved the architectural simplicity and test coverage."},
    {"id": "MJ-2026-035", "date": "2026-11-18", "time": "20:15", "mood_score": 7, "mood_label": "Content", "energy_level": 7, "stress_level": 4, "sleep_hours": 7.2, "tags": ["review", "writing"], "notes": "Drafted comprehensive project documentation."},
    {"id": "MJ-2026-036", "date": "2026-11-19", "time": "22:00", "mood_score": 9, "mood_label": "Grateful", "energy_level": 8, "stress_level": 2, "sleep_hours": 8.0, "tags": ["reflection", "teamwork"], "notes": "Grateful for team collaboration throughout the hackathon journey."},
    {"id": "MJ-2026-037", "date": "2026-11-20", "time": "19:45", "mood_score": 8, "mood_label": "Calm", "energy_level": 7, "stress_level": 3, "sleep_hours": 7.6, "tags": ["wrapup", "testing"], "notes": "Finalizing test suites and packaging the application."},
    {"id": "MJ-2026-038", "date": "2026-11-21", "time": "14:00", "mood_score": 9, "mood_label": "Joyful", "energy_level": 9, "stress_level": 2, "sleep_hours": 8.0, "tags": ["submission", "hackathon", "milestone"], "notes": "Today: Mood Journal Analyzer ready for presentation and final submission!"},
]


LEGACY_IMPORT_SAMPLE = [
    # Normal legacy entries with variant headers (timestamp, mood, feeling, energy, stress, sleep, tags, reflection)
    {"Entry Date": "2026-09-01", "Time": "08:00", "Mood Rating": "7", "Feeling": "Calm", "Energy Score": "6", "Tension": "3", "Hours Slept": "7.5", "Tags": "morning,tea", "Reflection": "Legacy record 1"},
    {"Entry Date": "2026-09-02", "Time": "12:30", "Mood Rating": "8", "Feeling": "Joyful", "Energy Score": "8", "Tension": "2", "Hours Slept": "8.0", "Tags": "work,lunch", "Reflection": "Legacy record 2"},
    {"Entry Date": "2026-09-03", "Time": "21:00", "Mood Rating": "6", "Feeling": "Neutral", "Energy Score": "5", "Tension": "5", "Hours Slept": "6.5", "Tags": "routine", "Reflection": "Legacy record 3"},
    {"Entry Date": "2026-09-04", "Time": "19:45", "Mood Rating": "5", "Feeling": "Tired", "Energy Score": "4", "Tension": "6", "Hours Slept": "6.0", "Tags": "commute", "Reflection": "Legacy record 4"},
    {"Entry Date": "2026-09-05", "Time": "22:15", "Mood Rating": "9", "Feeling": "Grateful", "Energy Score": "8", "Tension": "2", "Hours Slept": "8.5", "Tags": "weekend", "Reflection": "Legacy record 5"},
    {"Entry Date": "2026-09-06", "Time": "14:00", "Mood Rating": "7", "Feeling": "Motivated", "Energy Score": "7", "Tension": "3", "Hours Slept": "7.8", "Tags": "study", "Reflection": "Legacy record 6"},
    {"Entry Date": "2026-09-07", "Time": "18:00", "Mood Rating": "8", "Feeling": "Content", "Energy Score": "7", "Tension": "4", "Hours Slept": "7.2", "Tags": "gym", "Reflection": "Legacy record 7"},
    {"Entry Date": "2026-09-08", "Time": "20:30", "Mood Rating": "6", "Feeling": "", "Energy Score": "5", "Tension": "4", "Hours Slept": "7.0", "Tags": "reading", "Reflection": "Legacy record 8 without feeling"},
    {"Entry Date": "2026-09-09", "Time": "22:00", "Mood Rating": "7", "Feeling": "Calm", "Energy Score": "6", "Tension": "3", "Hours Slept": "7.5", "Tags": "walk", "Reflection": "Legacy record 9"},
    {"Entry Date": "2026-09-10", "Time": "21:00", "Mood Rating": "8", "Feeling": "Joyful", "Energy Score": "8", "Tension": "2", "Hours Slept": "8.2", "Tags": "family", "Reflection": "Legacy record 10"},

    # Intentional Invalid Rows to demonstrate defensive validation & error logging
    {"Entry Date": "2026-13-45", "Time": "12:00", "Mood Rating": "8", "Feeling": "ErrorDate", "Energy Score": "7", "Tension": "3", "Hours Slept": "7.0", "Tags": "bad_date", "Reflection": "Intentional error: invalid month 13 and day 45"},
    {"Entry Date": "2026-09-12", "Time": "14:00", "Mood Rating": "25", "Feeling": "OutOfRange", "Energy Score": "5", "Tension": "4", "Hours Slept": "7.0", "Tags": "bad_score", "Reflection": "Intentional error: mood score 25 is > 10"},
    {"Entry Date": "2026-09-13", "Time": "16:00", "Mood Rating": "7", "Feeling": "BadSleep", "Energy Score": "6", "Tension": "3", "Hours Slept": "-4.5", "Tags": "negative_sleep", "Reflection": "Intentional error: negative sleep hours"},
    {"Entry Date": "2026-09-14", "Time": "25:99", "Mood Rating": "6", "Feeling": "BadTime", "Energy Score": "5", "Tension": "4", "Hours Slept": "7.0", "Tags": "bad_time", "Reflection": "Intentional error: time 25:99 out of range"},
]


def generate():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Write sample_data.json
    sample_json_path = DATA_DIR / "sample_data.json"
    with open(sample_json_path, mode="w", encoding="utf-8") as f:
        json.dump({
            "schema_version": "1.0",
            "last_modified": datetime.now().isoformat(),
            "total_records": len(SAMPLE_ENTRIES),
            "entries": SAMPLE_ENTRIES
        }, f, indent=2)
    print(f"Generated {sample_json_path.name} with {len(SAMPLE_ENTRIES)} entries.")

    # 2. Write sample_data.csv
    sample_csv_path = DATA_DIR / "sample_data.csv"
    with open(sample_csv_path, mode="w", newline="", encoding="utf-8") as f:
        fieldnames = ["id", "date", "time", "mood_score", "mood_label", "energy_level", "stress_level", "sleep_hours", "tags", "notes", "created_at", "updated_at"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for e in SAMPLE_ENTRIES:
            writer.writerow({
                "id": e["id"],
                "date": e["date"],
                "time": e["time"],
                "mood_score": str(e["mood_score"]),
                "mood_label": e["mood_label"] or "",
                "energy_level": str(e["energy_level"]),
                "stress_level": str(e["stress_level"]),
                "sleep_hours": f"{e['sleep_hours']:.1f}",
                "tags": ";".join(e["tags"]),
                "notes": e["notes"],
                "created_at": f"{e['date']}T{e['time']}:00",
                "updated_at": f"{e['date']}T{e['time']}:00",
            })
    print(f"Generated {sample_csv_path.name} with {len(SAMPLE_ENTRIES)} entries.")

    # 3. Copy to active mood_journal.json and mood_journal.csv so app has active data immediately
    active_json = DATA_DIR / "mood_journal.json"
    with open(active_json, mode="w", encoding="utf-8") as f:
        json.dump({
            "schema_version": "1.0",
            "last_modified": datetime.now().isoformat(),
            "total_records": len(SAMPLE_ENTRIES),
            "entries": SAMPLE_ENTRIES
        }, f, indent=2)

    active_csv = DATA_DIR / "mood_journal.csv"
    with open(active_csv, mode="w", newline="", encoding="utf-8") as f:
        fieldnames = ["id", "date", "time", "mood_score", "mood_label", "energy_level", "stress_level", "sleep_hours", "tags", "notes", "created_at", "updated_at"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for e in SAMPLE_ENTRIES:
            writer.writerow({
                "id": e["id"],
                "date": e["date"],
                "time": e["time"],
                "mood_score": str(e["mood_score"]),
                "mood_label": e["mood_label"] or "",
                "energy_level": str(e["energy_level"]),
                "stress_level": str(e["stress_level"]),
                "sleep_hours": f"{e['sleep_hours']:.1f}",
                "tags": ";".join(e["tags"]),
                "notes": e["notes"],
                "created_at": f"{e['date']}T{e['time']}:00",
                "updated_at": f"{e['date']}T{e['time']}:00",
            })
    print(f"Copied sample records into active storage files {active_json.name} and {active_csv.name}.")

    # 4. Write legacy_import_sample.csv
    legacy_path = DATA_DIR / "legacy_import_sample.csv"
    with open(legacy_path, mode="w", newline="", encoding="utf-8") as f:
        fieldnames = list(LEGACY_IMPORT_SAMPLE[0].keys())
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in LEGACY_IMPORT_SAMPLE:
            writer.writerow(row)
    print(f"Generated {legacy_path.name} with {len(LEGACY_IMPORT_SAMPLE)} rows (including 4 intentional invalid rows for error-log demo).")


if __name__ == "__main__":
    generate()
